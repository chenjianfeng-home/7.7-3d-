@echo off
chcp 65001 >nul
title HELIOS // 天穹轨道站
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  [!] 未找到 Node.js。
  echo      请安装 Node.js 18+，或在本目录运行：
  echo      python -m http.server 8123
  echo.
  pause
  exit /b 1
)

start "" powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 2; Start-Process 'http://127.0.0.1:8123'"
node server.mjs
pause
