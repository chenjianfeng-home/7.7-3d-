import * as THREE from 'three';

const PLANETS = [
  { key: 'mercury', cn: '水星', en: 'MERCURY', orbit: 640, radius: 9, speed: 0.075, spin: 0.05, color: '#b8a795', texture: 'mercury', tilt: 0.01 },
  { key: 'venus', cn: '金星', en: 'VENUS', orbit: 1010, radius: 21, speed: 0.048, spin: -0.025, color: '#e0b878', texture: 'venus', tilt: 2.6 },
  { key: 'earth', cn: '地球', en: 'EARTH · 1.00 AU', orbit: 2800, radius: 90, speed: 0.0, spin: 0.0, color: '#6cb6ff', texture: 'earthDay', tilt: 23.44 },
  { key: 'mars', cn: '火星', en: 'MARS · 1.52 AU', orbit: 3540, radius: 15, speed: 0.03, spin: 0.045, color: '#d57b4e', texture: 'mars', tilt: 25.2 },
  { key: 'jupiter', cn: '木星', en: 'JUPITER · 5.20 AU', orbit: 4780, radius: 188, speed: 0.017, spin: 0.06, color: '#d9b48b', texture: 'jupiter', tilt: 3.1 },
  { key: 'saturn', cn: '土星', en: 'SATURN · 9.58 AU', orbit: 6180, radius: 158, speed: 0.011, spin: 0.05, color: '#e3c894', texture: 'saturn', tilt: 26.7 },
  { key: 'uranus', cn: '天王星', en: 'URANUS · 19.2 AU', orbit: 7320, radius: 76, speed: 0.007, spin: 0.04, color: '#93dce5', texture: 'uranus', tilt: 97.8 },
  { key: 'neptune', cn: '海王星', en: 'NEPTUNE · 30.1 AU', orbit: 8240, radius: 73, speed: 0.0045, spin: 0.05, color: '#618cff', texture: 'neptune', tilt: 28.3 },
];

const SUN_RADIUS = 265;

function makeRadialTexture(stops) {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');
  const g = ctx.createRadialGradient(256, 256, 0, 256, 256, 256);
  stops.forEach(([stop, color]) => g.addColorStop(stop, color));
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 512, 512);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function makeSunMaterial() {
  return new THREE.ShaderMaterial({
    uniforms: { time: { value: 0 } },
    vertexShader: /* glsl */`
      varying vec2 vUv;
      varying vec3 vNormalW;
      varying vec3 vPositionW;
      void main() {
        vUv = uv;
        vNormalW = normalize(mat3(modelMatrix) * normal);
        vec4 world = modelMatrix * vec4(position, 1.0);
        vPositionW = world.xyz;
        gl_Position = projectionMatrix * viewMatrix * world;
      }
    `,
    fragmentShader: /* glsl */`
      precision highp float;
      uniform float time;
      varying vec2 vUv;
      varying vec3 vNormalW;
      varying vec3 vPositionW;

      float hash(vec2 p) {
        return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
      }
      float noise(vec2 p) {
        vec2 i = floor(p);
        vec2 f = fract(p);
        f = f * f * (3.0 - 2.0 * f);
        float a = hash(i);
        float b = hash(i + vec2(1.0, 0.0));
        float c = hash(i + vec2(0.0, 1.0));
        float d = hash(i + vec2(1.0, 1.0));
        return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
      }
      float fbm(vec2 p) {
        float v = 0.0;
        float a = 0.5;
        for (int i = 0; i < 5; i++) {
          v += a * noise(p);
          p *= 2.02;
          a *= 0.5;
        }
        return v;
      }

      void main() {
        vec2 p = vUv * vec2(24.0, 12.0);
        float n = fbm(p + vec2(0.0, time * 0.07));
        float n2 = fbm(p * 2.1 - vec2(time * 0.11, 0.0));
        float cells = smoothstep(0.35, 0.8, n + n2 * 0.45);
        vec3 deep = vec3(0.62, 0.12, 0.008);
        vec3 mid = vec3(1.0, 0.42, 0.03);
        vec3 hot = vec3(1.0, 0.88, 0.58);
        vec3 col = mix(deep, mid, smoothstep(0.2, 0.62, n));
        col = mix(col, hot, cells * 0.85);
        col += vec3(1.0, 0.32, 0.03) * pow(n2, 3.0) * 0.7;

        vec3 V = normalize(cameraPosition - vPositionW);
        float rim = pow(1.0 - max(dot(normalize(vNormalW), V), 0.0), 1.8);
        col += vec3(1.0, 0.44, 0.06) * rim * 1.8;

        gl_FragColor = vec4(col * 2.1, 1.0);
      }
    `,
  });
}

function createOrbitLine(radius, color, opacity, segments = 512) {
  const points = [];
  for (let i = 0; i <= segments; i += 1) {
    const a = (i / segments) * Math.PI * 2;
    points.push(new THREE.Vector3(Math.cos(a) * radius, 0, Math.sin(a) * radius));
  }
  const geometry = new THREE.BufferGeometry().setFromPoints(points);
  return new THREE.Line(
    geometry,
    new THREE.LineBasicMaterial({
      color,
      transparent: true,
      opacity,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
}

function createSaturnRing(inner, outer, opacity = 1, tint = [0.62, 0.53, 0.4]) {
  const material = new THREE.ShaderMaterial({
    uniforms: {
      inner: { value: inner },
      outer: { value: outer },
      tint: { value: new THREE.Vector3(...tint) },
      opacity: { value: opacity },
    },
    vertexShader: /* glsl */`
      varying vec2 vPos;
      varying vec2 vUv;
      void main() {
        vPos = position.xy;
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: /* glsl */`
      precision highp float;
      uniform float inner;
      uniform float outer;
      uniform vec3 tint;
      uniform float opacity;
      varying vec2 vPos;
      varying vec2 vUv;

      void main() {
        float r = length(vPos);
        float t = (r - inner) / (outer - inner);
        float bands = 0.45
          + 0.18 * sin(r * 0.42)
          + 0.12 * sin(r * 1.27 + 1.2)
          + 0.08 * sin(r * 2.9);
        float gapA = smoothstep(0.018, 0.0, abs(t - 0.34));
        float gapB = smoothstep(0.013, 0.0, abs(t - 0.58));
        float gapC = smoothstep(0.008, 0.0, abs(t - 0.79));
        float alpha = smoothstep(0.0, 0.05, t) * (1.0 - smoothstep(0.9, 1.0, t));
        alpha *= 1.0 - gapA * 0.8 - gapB * 0.9 - gapC * 0.7;
        vec3 col = tint * (0.55 + bands * 0.8);
        col += vec3(0.18, 0.12, 0.06) * bands;
        gl_FragColor = vec4(col, alpha * bands * opacity);
      }
    `,
    side: THREE.DoubleSide,
    transparent: true,
    depthWrite: false,
  });

  const ring = new THREE.Mesh(new THREE.RingGeometry(inner, outer, 256, 2), material);
  ring.rotation.x = -Math.PI / 2;
  return ring;
}

function createPlanet(data, texture) {
  const orbitGroup = new THREE.Group();
  orbitGroup.rotation.y = Math.random() * Math.PI * 2;
  orbitGroup.rotation.x = THREE.MathUtils.degToRad((Math.random() - 0.5) * 1.4);

  const tiltGroup = new THREE.Group();
  tiltGroup.position.set(data.orbit, 0, 0);
  tiltGroup.rotation.z = THREE.MathUtils.degToRad(data.tilt);
  orbitGroup.add(tiltGroup);

  const material = new THREE.MeshStandardMaterial({
    map: texture,
    color: texture ? 0xffffff : new THREE.Color(data.color),
    roughness: data.key === 'jupiter' || data.key === 'saturn' ? 0.92 : 0.98,
    metalness: 0.0,
    emissive: new THREE.Color(data.key === 'venus' ? 0x2a1504 : 0x000000),
    emissiveIntensity: data.key === 'venus' ? 0.6 : 1,
  });

  const mesh = new THREE.Mesh(new THREE.SphereGeometry(data.radius, 64, 48), material);
  mesh.rotation.y = Math.random() * Math.PI * 2;
  tiltGroup.add(mesh);

  let ring = null;
  if (data.key === 'saturn') {
    ring = createSaturnRing(data.radius * 1.38, data.radius * 2.32, 0.95, [0.68, 0.58, 0.43]);
    tiltGroup.add(ring);
    const ringInner = createSaturnRing(data.radius * 1.18, data.radius * 1.28, 0.4, [0.45, 0.4, 0.32]);
    tiltGroup.add(ringInner);
  }
  if (data.key === 'uranus') {
    ring = createSaturnRing(data.radius * 1.5, data.radius * 1.72, 0.22, [0.4, 0.62, 0.68]);
    tiltGroup.add(ring);
  }

  return { orbitGroup, tiltGroup, mesh, ring };
}

export function createSolarSystem(textures) {
  const group = new THREE.Group();
  group.name = 'SOLAR_SYSTEM';

  const sunMaterial = makeSunMaterial();
  const sun = new THREE.Mesh(new THREE.SphereGeometry(SUN_RADIUS, 96, 64), sunMaterial);
  group.add(sun);

  const sunGlow = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: makeRadialTexture([
        [0, 'rgba(255,255,245,1)'],
        [0.18, 'rgba(255,225,160,0.85)'],
        [0.42, 'rgba(255,130,35,0.4)'],
        [0.7, 'rgba(255,80,10,0.1)'],
        [1, 'rgba(255,60,0,0)'],
      ]),
      color: 0xffc884,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
  sunGlow.scale.setScalar(SUN_RADIUS * 7.4);
  group.add(sunGlow);

  const sunHalo = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: makeRadialTexture([
        [0, 'rgba(255,190,120,0.42)'],
        [0.4, 'rgba(255,110,40,0.16)'],
        [1, 'rgba(255,70,0,0)'],
      ]),
      color: 0xff9b52,
      transparent: true,
      opacity: 0.7,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
  sunHalo.scale.setScalar(SUN_RADIUS * 15);
  group.add(sunHalo);

  const orbitGroup = new THREE.Group();
  group.add(orbitGroup);

  const planets = [];
  const orbitLines = [];

  PLANETS.forEach((data) => {
    if (data.key === 'earth') {
      const line = createOrbitLine(data.orbit, 0x4f9dff, 0.28);
      orbitGroup.add(line);
      orbitLines.push(line);
      return;
    }
    const texture = textures[data.texture];
    const built = createPlanet(data, texture);
    orbitGroup.add(built.orbitGroup);
    const orbitLine = createOrbitLine(data.orbit, 0x6b8aa8, 0.12);
    orbitGroup.add(orbitLine);
    orbitLines.push(orbitLine);

    planets.push({
      ...data,
      ...built,
      anchor: built.mesh,
    });
  });

  // asteroid belt
  const beltCount = 2400;
  const beltPositions = new Float32Array(beltCount * 3);
  for (let i = 0; i < beltCount; i += 1) {
    const radius = 3820 + (Math.random() - 0.5) * 520;
    const angle = Math.random() * Math.PI * 2;
    beltPositions[i * 3] = Math.cos(angle) * radius;
    beltPositions[i * 3 + 1] = (Math.random() - 0.5) * 90;
    beltPositions[i * 3 + 2] = Math.sin(angle) * radius;
  }
  const beltGeometry = new THREE.BufferGeometry();
  beltGeometry.setAttribute('position', new THREE.BufferAttribute(beltPositions, 3));
  const belt = new THREE.Points(
    beltGeometry,
    new THREE.PointsMaterial({
      color: 0x8e9cac,
      size: 2.6,
      sizeAttenuation: true,
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
    })
  );
  group.add(belt);

  // distant comet / kuiper sparks
  const dustCount = 900;
  const dustPositions = new Float32Array(dustCount * 3);
  for (let i = 0; i < dustCount; i += 1) {
    const radius = 8600 + Math.random() * 2600;
    const angle = Math.random() * Math.PI * 2;
    dustPositions[i * 3] = Math.cos(angle) * radius;
    dustPositions[i * 3 + 1] = (Math.random() - 0.5) * 600;
    dustPositions[i * 3 + 2] = Math.sin(angle) * radius;
  }
  const dustGeometry = new THREE.BufferGeometry();
  dustGeometry.setAttribute('position', new THREE.BufferAttribute(dustPositions, 3));
  const dust = new THREE.Points(
    dustGeometry,
    new THREE.PointsMaterial({
      color: 0x627896,
      size: 3.2,
      transparent: true,
      opacity: 0.36,
      depthWrite: false,
    })
  );
  group.add(dust);

  let elapsed = 0;

  function update(delta, timeScale = 1) {
    const d = delta * timeScale;
    elapsed += d;
    sunMaterial.uniforms.time.value = elapsed;
    sun.rotation.y += d * 0.006;
    sunGlow.material.rotation = Math.sin(elapsed * 0.05) * 0.05;
    const pulse = 1 + Math.sin(elapsed * 0.55) * 0.018;
    sunGlow.scale.setScalar(SUN_RADIUS * 7.4 * pulse);

    planets.forEach((planet) => {
      planet.orbitGroup.rotation.y += d * planet.speed * 0.32;
      planet.mesh.rotation.y += d * planet.spin;
    });

    belt.rotation.y += d * 0.006;
    dust.rotation.y -= d * 0.002;
  }

  return {
    group,
    sun,
    sunGlow,
    planets,
    orbitLines,
    belt,
    dust,
    update,
    sunRadius: SUN_RADIUS,
    labelData: [
      { key: 'sun', cn: '太阳', en: 'SOL · G2V', color: '#ffbd7a', anchor: sun, isSun: true },
      ...planets.map((p) => ({
        key: p.key,
        cn: p.cn,
        en: p.en,
        color: p.color,
        anchor: p.anchor,
      })),
    ],
  };
}
