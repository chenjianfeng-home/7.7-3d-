import * as THREE from 'three';

/* ═══════════════════════════════════════════════════════════
   HELIOS LONG-RANGE CRUISER
   The ship that actually flies the 30-second planetary route.
   Built facing +Z.
   ═══════════════════════════════════════════════════════════ */

function makeGlowTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.14, 'rgba(220,250,255,0.95)');
  g.addColorStop(0.38, 'rgba(80,210,255,0.28)');
  g.addColorStop(1, 'rgba(30,120,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 128, 128);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function wingGeometry() {
  const shape = new THREE.Shape();
  shape.moveTo(0, 3.0);
  shape.lineTo(9.2, 0.4);
  shape.lineTo(8.2, -3.6);
  shape.lineTo(2.0, -4.6);
  shape.lineTo(0, -2.0);
  shape.closePath();
  const geometry = new THREE.ExtrudeGeometry(shape, {
    depth: 0.28,
    bevelEnabled: false,
    steps: 1,
  });
  geometry.rotateX(-Math.PI / 2);
  geometry.translate(0, 0.14, 0);
  return geometry;
}

export function createCruiser() {
  const group = new THREE.Group();
  group.name = 'HELIOS_CRUISER';

  const glowTexture = makeGlowTexture();

  const hull = new THREE.MeshStandardMaterial({
    color: 0x5d6a7a,
    metalness: 0.92,
    roughness: 0.3,
    envMapIntensity: 1.5,
  });
  const hullLight = new THREE.MeshStandardMaterial({
    color: 0xd6e0eb,
    metalness: 0.82,
    roughness: 0.32,
    envMapIntensity: 1.2,
  });
  const hullDark = new THREE.MeshStandardMaterial({
    color: 0x10151d,
    metalness: 0.85,
    roughness: 0.4,
  });
  const gold = new THREE.MeshStandardMaterial({
    color: 0xb48848,
    metalness: 1,
    roughness: 0.26,
  });
  const cyan = new THREE.MeshBasicMaterial({
    color: new THREE.Color(0x8fe9ff).multiplyScalar(3.2),
    toneMapped: false,
  });
  const amber = new THREE.MeshBasicMaterial({
    color: new THREE.Color(0xffb46e).multiplyScalar(2.8),
    toneMapped: false,
  });
  const glass = new THREE.MeshStandardMaterial({
    color: 0x05131e,
    metalness: 0.65,
    roughness: 0.12,
    emissive: new THREE.Color(0x0b4c63),
    emissiveIntensity: 1.8,
  });

  // main fuselage
  const body = new THREE.Mesh(new THREE.CylinderGeometry(1.65, 2.45, 14.5, 24), hull);
  body.rotation.x = Math.PI / 2;
  group.add(body);

  // nose
  const nose = new THREE.Mesh(new THREE.ConeGeometry(1.65, 5.0, 24), hullLight);
  nose.rotation.x = Math.PI / 2;
  nose.position.z = 9.7;
  group.add(nose);

  const noseTip = new THREE.Mesh(new THREE.ConeGeometry(0.45, 1.6, 16), gold);
  noseTip.rotation.x = Math.PI / 2;
  noseTip.position.z = 12.7;
  group.add(noseTip);

  // cockpit
  const canopy = new THREE.Mesh(new THREE.SphereGeometry(1.35, 32, 20), glass);
  canopy.scale.set(0.82, 0.48, 2.25);
  canopy.position.set(0, 1.05, 4.5);
  group.add(canopy);

  const canopyFrame = new THREE.Mesh(new THREE.TorusGeometry(1.1, 0.12, 8, 32), gold);
  canopyFrame.rotation.x = Math.PI / 2;
  canopyFrame.scale.set(1.0, 1.7, 1);
  canopyFrame.position.set(0, 1.1, 3.7);
  group.add(canopyFrame);

  // dorsal spine and fins
  const spine = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.45, 9.5), hullDark);
  spine.position.set(0, 1.55, -1.4);
  group.add(spine);
  const dorsalFin = new THREE.Mesh(new THREE.BoxGeometry(0.22, 2.2, 3.0), hullDark);
  dorsalFin.position.set(0, 2.35, -5.4);
  dorsalFin.rotation.x = -0.35;
  group.add(dorsalFin);

  // wings
  const wingGeo = wingGeometry();
  const wingLeft = new THREE.Mesh(wingGeo, hull);
  wingLeft.scale.x = -1;
  wingLeft.position.set(-0.5, -0.1, -1.6);
  group.add(wingLeft);
  const wingRight = new THREE.Mesh(wingGeo, hull);
  wingRight.position.set(0.5, -0.1, -1.6);
  group.add(wingRight);

  const wingTopLeft = new THREE.Mesh(wingGeo, hullDark);
  wingTopLeft.scale.set(-0.76, 0.55, 0.76);
  wingTopLeft.position.set(-0.5, 0.34, -2.2);
  group.add(wingTopLeft);
  const wingTopRight = new THREE.Mesh(wingGeo, hullDark);
  wingTopRight.scale.set(0.76, 0.55, 0.76);
  wingTopRight.position.set(0.5, 0.34, -2.2);
  group.add(wingTopRight);

  // wingtip fins
  [-1, 1].forEach((side) => {
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.18, 2.0, 1.4), hullLight);
    fin.position.set(side * 8.4, 0.85, -3.9);
    fin.rotation.z = side * -0.28;
    group.add(fin);

    const finGlow = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.5, 0.7), side > 0 ? cyan : amber);
    finGlow.position.set(side * 8.42, 1.12, -3.8);
    group.add(finGlow);
  });

  // wing leading-edge light strips
  [-1, 1].forEach((side) => {
    const strip = new THREE.Mesh(new THREE.BoxGeometry(7.2, 0.055, 0.09), cyan);
    strip.position.set(side * 4.3, 0.3, 0.8);
    strip.rotation.y = side * 0.26;
    group.add(strip);
  });

  // side light strips
  [-1, 1].forEach((side) => {
    const strip = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.12, 8.8), cyan);
    strip.position.set(side * 2.1, 0.1, 1.5);
    group.add(strip);
  });

  // gold thermal collar
  const collar = new THREE.Mesh(new THREE.TorusGeometry(2.2, 0.16, 8, 32), gold);
  collar.rotation.x = Math.PI / 2;
  collar.position.z = 1.5;
  group.add(collar);

  // engine nacelles
  const engineGlows = [];
  [-1, 1].forEach((side) => {
    const nacelle = new THREE.Mesh(new THREE.CylinderGeometry(1.05, 1.3, 6.2, 18), hullDark);
    nacelle.rotation.x = Math.PI / 2;
    nacelle.position.set(side * 3.15, -0.35, -6.3);
    group.add(nacelle);

    const ring = new THREE.Mesh(new THREE.TorusGeometry(1.06, 0.13, 8, 24), cyan);
    ring.position.set(side * 3.15, -0.35, -9.35);
    group.add(ring);

    const nozzle = new THREE.Mesh(new THREE.CylinderGeometry(0.78, 1.0, 1.2, 18), hull);
    nozzle.rotation.x = Math.PI / 2;
    nozzle.position.set(side * 3.15, -0.35, -10.0);
    group.add(nozzle);

    const glow = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: glowTexture,
        color: 0x64dcff,
        transparent: true,
        opacity: 0.9,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );
    glow.scale.setScalar(7.5);
    glow.position.set(side * 3.15, -0.35, -10.8);
    group.add(glow);
    engineGlows.push(glow);
  });

  // central exhaust
  const centerGlow = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: glowTexture,
      color: 0x9feeff,
      transparent: true,
      opacity: 0.65,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
  centerGlow.scale.setScalar(4.5);
  centerGlow.position.set(0, 0, -8.8);
  group.add(centerGlow);
  engineGlows.push(centerGlow);

  // greebles / panel details
  for (let i = 0; i < 26; i += 1) {
    const side = i % 2 ? 1 : -1;
    const a = (i / 26) * Math.PI * 2;
    const detail = new THREE.Mesh(
      new THREE.BoxGeometry(0.18 + (i % 3) * 0.12, 0.12, 0.8 + (i % 4) * 0.3),
      i % 5 === 0 ? gold : hullDark
    );
    detail.position.set(
      side * (1.8 + (i % 3) * 0.45),
      Math.cos(a) * 1.5,
      -4 + (i % 7) * 1.2
    );
    group.add(detail);
  }

  // antenna
  const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.05, 2.4, 6), hullLight);
  antenna.position.set(0.7, 2.0, 3.0);
  group.add(antenna);
  const antennaTip = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 8), amber);
  antennaTip.position.set(0.7, 3.2, 3.0);
  group.add(antennaTip);

  // practical light from the engines
  const engineLight = new THREE.PointLight(0x5fd8ff, 24, 30, 2);
  engineLight.position.set(0, 0, -9.5);
  group.add(engineLight);

  const keyLight = new THREE.PointLight(0xd7efff, 240, 65, 2);
  keyLight.position.set(2, 5, 12);
  group.add(keyLight);

  const rimLight = new THREE.PointLight(0x4fb9ff, 90, 50, 2);
  rimLight.position.set(-4, -3, -7);
  group.add(rimLight);

  let elapsed = 0;

  function update(delta, intensity = 1) {
    elapsed += delta;
    const pulse = 0.72 + Math.sin(elapsed * 8.6) * 0.12 + Math.sin(elapsed * 21.3) * 0.06;
    engineGlows.forEach((glow, index) => {
      const base = index === engineGlows.length - 1 ? 4.5 : 7.5;
      glow.scale.setScalar(base * pulse * (0.92 + intensity * 0.12));
      glow.material.opacity = (0.62 + pulse * 0.3) * intensity;
    });
    engineLight.intensity = (16 + pulse * 10) * intensity;
    amber.opacity = 1;
    group.rotation.z *= 1;
  }

  group.scale.setScalar(1.3);
  return { group, update };
}
