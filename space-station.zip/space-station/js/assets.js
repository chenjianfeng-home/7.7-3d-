import * as THREE from 'three';

const TEXTURE_FILES = {
  earthDay: './assets/textures/2k_earth_daymap_full.jpg',
  earthNight: './assets/textures/2k_earth_nightmap_full.jpg',
  earthClouds: './assets/textures/2k_earth_clouds_full.jpg',
  earthNormal: './assets/textures/earth_normal_2048.jpg',
  earthSpec: './assets/textures/earth_specular_2048.jpg',
  moon: './assets/textures/2k_moon.jpg',
  mercury: './assets/textures/2k_mercury.jpg',
  venus: './assets/textures/2k_venus_surface.jpg',
  mars: './assets/textures/2k_mars.jpg',
  jupiter: './assets/textures/2k_jupiter.jpg',
  saturn: './assets/textures/2k_saturn.jpg',
  uranus: './assets/textures/2k_uranus.jpg',
  neptune: './assets/textures/2k_neptune.jpg',
};

const COLOR_MAPS = new Set([
  'earthDay', 'earthNight', 'earthClouds', 'moon', 'mercury', 'venus',
  'mars', 'jupiter', 'saturn', 'uranus', 'neptune',
]);

export function loadTextures(onProgress, maxAnisotropy = 8) {
  const loader = new THREE.TextureLoader();
  const keys = Object.keys(TEXTURE_FILES);
  const result = {};
  let done = 0;
  let failed = 0;

  const promise = Promise.all(keys.map((key) => new Promise((resolve) => {
    loader.load(
      TEXTURE_FILES[key],
      (texture) => {
        texture.colorSpace = COLOR_MAPS.has(key) ? THREE.SRGBColorSpace : THREE.NoColorSpace;
        texture.anisotropy = maxAnisotropy;
        if (key === 'earthDay' || key === 'earthNight' || key === 'earthClouds' || key === 'earthNormal') {
          texture.wrapS = THREE.RepeatWrapping;
        }
        texture.needsUpdate = true;
        result[key] = texture;
        done += 1;
        onProgress?.((done / keys.length) * 100, failed);
        resolve();
      },
      undefined,
      () => {
        result[key] = null;
        failed += 1;
        done += 1;
        onProgress?.((done / keys.length) * 100, failed);
        resolve();
      }
    );
  })));

  return promise.then(() => result);
}

export function canvasTexture(width, height, draw) {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  draw(ctx, width, height);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 8;
  return texture;
}

export function fallbackPlanetTexture(base = '#8a6a53', accent = '#d8c3a5') {
  return canvasTexture(512, 256, (ctx, w, h) => {
    const g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, base);
    g.addColorStop(0.5, accent);
    g.addColorStop(1, base);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 900; i += 1) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      const r = Math.random() * 10 + 1;
      ctx.fillStyle = `rgba(${Math.random() > 0.5 ? '255,255,255' : '0,0,0'},${Math.random() * 0.045})`;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }
  });
}
