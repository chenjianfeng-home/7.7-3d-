import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';

import { loadTextures } from './assets.js';
import { createEarth } from './earth.js';
import { createSolarSystem } from './solar.js';
import { createStation } from './station.js';
import { createCruiser } from './ship.js';

/* ────────────────────────────────────────────────────────────
   constants
   ──────────────────────────────────────────────────────────── */

const EARTH_POSITION = new THREE.Vector3(2800, 0, 0);
const STATION_OFFSET = new THREE.Vector3(-135, 180, 115);
const isCoarsePointer = window.matchMedia('(pointer: coarse)').matches;
const query = new URLSearchParams(window.location.search);

const dom = {
  intro: document.getElementById('intro'),
  loadBar: document.getElementById('loadBar'),
  loadPct: document.getElementById('loadPct'),
  loadStatus: document.getElementById('loadStatus'),
  enterBtn: document.getElementById('enterBtn'),
  hud: document.getElementById('hud'),
  clock: document.getElementById('clock'),
  alt: document.getElementById('altVal'),
  vel: document.getElementById('velVal'),
  fps: document.getElementById('fpsVal'),
  speed: document.getElementById('speedVal'),
  speedRange: document.getElementById('speedRange'),
  pauseBtn: document.getElementById('pauseBtn'),
  cruiseHud: document.getElementById('cruiseHud'),
  cruiseRate: document.getElementById('cruiseRate'),
  cruiseRange: document.getElementById('cruiseRange'),
  cruisePause: document.getElementById('cruisePause'),
  cruiseDir: document.getElementById('cruiseDir'),
  tourCaption: document.getElementById('tourCaption'),
  tourName: document.getElementById('tourName'),
  tourIndex: document.getElementById('tourIndex'),
  tourBar: document.getElementById('tourBar'),
  warpLines: document.getElementById('warpLines'),
  explodePanel: document.getElementById('explodePanel'),
  explodeParts: document.getElementById('explodeParts'),
  explodePct: document.getElementById('explodePct'),
  explodeBar: document.getElementById('explodeBar'),
  explodeList: document.getElementById('explodeList'),
  recomposeBtn: document.getElementById('recomposeBtn'),
  gameHud: document.getElementById('gameHud'),
  gameSpeed: document.getElementById('gameSpeed'),
  gameThrust: document.getElementById('gameThrust'),
  gameWarp: document.getElementById('gameWarp'),
  gameWarpState: document.getElementById('gameWarpState'),
  gameWarpBtn: document.getElementById('gameWarpBtn'),
  gameNearest: document.getElementById('gameNearest'),
  gameCoords: document.getElementById('gameCoords'),
  gameAttitude: document.getElementById('gameAttitude'),
  gameLock: document.getElementById('gameLock'),
  gameNav: document.getElementById('gameNav'),
  soundBtn: document.getElementById('soundBtn'),
  fullBtn: document.getElementById('fullBtn'),
  markers: document.getElementById('markers'),
  planetLabels: document.getElementById('planetLabels'),
  detail: document.getElementById('detail'),
  detailIndex: document.getElementById('detailIndex'),
  detailTitle: document.getElementById('detailTitle'),
  detailEn: document.getElementById('detailEn'),
  detailDesc: document.getElementById('detailDesc'),
  detailStats: document.getElementById('detailStats'),
  detailClose: document.getElementById('detailClose'),
  detailBack: document.getElementById('detailBack'),
  archive: document.getElementById('archive'),
  archiveBtn: document.getElementById('archiveBtn'),
  archiveClose: document.getElementById('archiveClose'),
  dossierTitle: document.getElementById('dossierTitle'),
  dossierEn: document.getElementById('dossierEn'),
  dossierDesc: document.getElementById('dossierDesc'),
  specGrid: document.getElementById('specGrid'),
  cursor: document.getElementById('cursor'),
  cursorDot: document.getElementById('cursorDot'),
};

/* ────────────────────────────────────────────────────────────
   renderer / scene / camera
   ──────────────────────────────────────────────────────────── */

const canvas = document.getElementById('scene');
const renderer = new THREE.WebGLRenderer({
  canvas,
  antialias: true,
  alpha: false,
  powerPreference: 'high-performance',
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.8));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.0;
renderer.setClearColor(0x010207, 1);

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(
  52,
  window.innerWidth / window.innerHeight,
  0.4,
  60000
);
camera.position.set(1450, 820, 2050);

const controls = new OrbitControls(camera, canvas);
controls.enableDamping = true;
controls.dampingFactor = 0.045;
controls.rotateSpeed = 0.42;
controls.zoomSpeed = 0.72;
controls.panSpeed = 0.35;
controls.enablePan = false;
controls.target.copy(EARTH_POSITION);
controls.enabled = false;
controls.minDistance = 20;
controls.maxDistance = 26000;
controls.autoRotateSpeed = 0.42;

/* environment for believable metal */
function createEnvironment() {
  const c = document.createElement('canvas');
  c.width = 1024;
  c.height = 512;
  const ctx = c.getContext('2d');
  const base = ctx.createLinearGradient(0, 0, 0, 512);
  base.addColorStop(0, '#07111f');
  base.addColorStop(0.42, '#0a1828');
  base.addColorStop(0.52, '#04080f');
  base.addColorStop(1, '#010206');
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, 1024, 512);

  const cool = ctx.createRadialGradient(300, 180, 20, 300, 180, 380);
  cool.addColorStop(0, 'rgba(90,170,255,0.32)');
  cool.addColorStop(0.5, 'rgba(30,80,170,0.09)');
  cool.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = cool;
  ctx.fillRect(0, 0, 1024, 512);

  const warm = ctx.createRadialGradient(790, 230, 10, 790, 230, 260);
  warm.addColorStop(0, 'rgba(255,180,110,0.34)');
  warm.addColorStop(0.45, 'rgba(255,120,40,0.08)');
  warm.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = warm;
  ctx.fillRect(0, 0, 1024, 512);

  const texture = new THREE.CanvasTexture(c);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.mapping = THREE.EquirectangularReflectionMapping;

  const pmrem = new THREE.PMREMGenerator(renderer);
  pmrem.compileEquirectangularShader();
  const env = pmrem.fromEquirectangular(texture).texture;
  texture.dispose();
  pmrem.dispose();
  return env;
}

scene.environment = createEnvironment();
scene.environmentIntensity = 0.9;

/* lights */
const sunLight = new THREE.DirectionalLight(0xfff0dc, 3.15);
sunLight.position.set(-8000, 900, 2200);
scene.add(sunLight);
scene.add(sunLight.target);

const fillLight = new THREE.DirectionalLight(0x4a78ff, 1.15);
fillLight.position.set(3600, 1100, 3200);
scene.add(fillLight);

const rimLight = new THREE.DirectionalLight(0x76e6ff, 0.8);
rimLight.position.set(1200, 3000, -3200);
scene.add(rimLight);

const ambient = new THREE.AmbientLight(0x203047, 0.55);
scene.add(ambient);

/* post processing */
const composer = new EffectComposer(renderer);
composer.addPass(new RenderPass(scene, camera));
const bloom = new UnrealBloomPass(
  new THREE.Vector2(window.innerWidth, window.innerHeight),
  0.82,
  0.52,
  0.8
);
composer.addPass(bloom);
composer.addPass(new OutputPass());

/* ────────────────────────────────────────────────────────────
   deep sky
   ──────────────────────────────────────────────────────────── */

function createStarfield() {
  const starGroup = new THREE.Group();
  starGroup.name = 'DEEP_SKY';

  const makeLayer = (count, radiusMin, radiusMax, sizeMin, sizeMax, band = false) => {
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const sizes = new Float32Array(count);
    const color = new THREE.Color();

    const bandNormal = new THREE.Vector3(0.26, 1.0, 0.3).normalize();
    const basisA = new THREE.Vector3(1, 0, 0.2).normalize();
    const basisB = new THREE.Vector3().crossVectors(bandNormal, basisA).normalize();

    for (let i = 0; i < count; i += 1) {
      const radius = radiusMin + Math.random() * (radiusMax - radiusMin);
      let x;
      let y;
      let z;

      if (band) {
        const theta = Math.random() * Math.PI * 2;
        const spread = (Math.random() + Math.random() + Math.random() - 1.5) * 1600;
        x = basisA.x * Math.cos(theta) * radius + basisB.x * Math.sin(theta) * radius + bandNormal.x * spread;
        y = basisA.y * Math.cos(theta) * radius + basisB.y * Math.sin(theta) * radius + bandNormal.y * spread;
        z = basisA.z * Math.cos(theta) * radius + basisB.z * Math.sin(theta) * radius + bandNormal.z * spread;
      } else {
        const u = Math.random() * 2 - 1;
        const theta = Math.random() * Math.PI * 2;
        const s = Math.sqrt(1 - u * u);
        x = Math.cos(theta) * s * radius;
        y = u * radius;
        z = Math.sin(theta) * s * radius;
      }

      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;

      const tint = Math.random();
      if (tint > 0.78) color.setRGB(0.45, 0.68, 1.0);
      else if (tint > 0.56) color.setRGB(1.0, 0.72, 0.48);
      else if (tint > 0.28) color.setRGB(0.78, 0.88, 1.0);
      else color.setRGB(0.95, 0.96, 1.0);
      const brightness = 0.3 + Math.random() * 0.7;
      colors[i * 3] = color.r * brightness;
      colors[i * 3 + 1] = color.g * brightness;
      colors[i * 3 + 2] = color.b * brightness;
      sizes[i] = sizeMin + Math.random() * (sizeMax - sizeMin);
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('aColor', new THREE.BufferAttribute(colors, 3));
    geometry.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));

    const material = new THREE.ShaderMaterial({
      uniforms: { time: { value: 0 }, pixelRatio: { value: Math.min(window.devicePixelRatio || 1, 1.8) } },
      vertexShader: /* glsl */`
        attribute vec3 aColor;
        attribute float aSize;
        uniform float time;
        uniform float pixelRatio;
        varying vec3 vColor;
        varying float vTwinkle;
        void main() {
          vColor = aColor;
          vTwinkle = 0.72 + 0.28 * sin(time * (0.5 + fract(aSize * 7.13) * 1.6) + aSize * 20.0);
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          gl_PointSize = aSize * pixelRatio;
          gl_Position = projectionMatrix * mv;
        }
      `,
      fragmentShader: /* glsl */`
        precision highp float;
        varying vec3 vColor;
        varying float vTwinkle;
        void main() {
          vec2 p = gl_PointCoord - 0.5;
          float d = length(p);
          float core = smoothstep(0.5, 0.02, d);
          float halo = smoothstep(0.5, 0.18, d) * 0.35;
          float alpha = (core + halo) * vTwinkle;
          if (alpha < 0.01) discard;
          gl_FragColor = vec4(vColor * (1.2 + core), alpha);
        }
      `,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });

    const points = new THREE.Points(geometry, material);
    points.frustumCulled = false;
    return { points, material };
  };

  const layerA = makeLayer(6200, 16000, 24000, 1.0, 2.4);
  const layerB = makeLayer(5200, 10000, 22000, 1.2, 3.2, true);
  const layerC = makeLayer(1800, 7000, 18000, 2.0, 4.2);
  starGroup.add(layerA.points, layerB.points, layerC.points);

  // faint galactic dust clouds
  const nebulaTexture = (() => {
    const c = document.createElement('canvas');
    c.width = 512;
    c.height = 512;
    const ctx = c.getContext('2d');
    const g = ctx.createRadialGradient(256, 256, 0, 256, 256, 256);
    g.addColorStop(0, 'rgba(120,150,255,0.18)');
    g.addColorStop(0.35, 'rgba(80,100,220,0.09)');
    g.addColorStop(0.7, 'rgba(120,60,200,0.025)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 512, 512);
    const texture = new THREE.CanvasTexture(c);
    texture.colorSpace = THREE.SRGBColorSpace;
    return texture;
  })();

  const nebulaPositions = [
    [-12000, 3200, -15000, 16000],
    [9000, -5000, -18000, 13000],
    [15000, 4000, 8000, 10500],
    [-16000, -6000, 9000, 14000],
  ];

  nebulaPositions.forEach(([x, y, z, scale], i) => {
    const sprite = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: nebulaTexture,
        color: i % 2 ? 0x6d86ff : 0x936cff,
        transparent: true,
        opacity: 0.16,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );
    sprite.position.set(x, y, z);
    sprite.scale.setScalar(scale);
    starGroup.add(sprite);
  });

  scene.add(starGroup);
  return {
    group: starGroup,
    update(t) {
      layerA.material.uniforms.time.value = t;
      layerB.material.uniforms.time.value = t;
      layerC.material.uniforms.time.value = t;
      starGroup.rotation.y = t * 0.00035;
    },
  };
}

const starfield = createStarfield();

/* ────────────────────────────────────────────────────────────
   world
   ──────────────────────────────────────────────────────────── */

let earth = null;
let solar = null;
let station = null;
let ship = null;
let worldReady = false;
let started = false;
let timeScale = 1;
let paused = false;
let cruiseSpeed = 1;
let cruiseDirection = 1;
let cruisePaused = false;
let tourWaypoints = [];
let tourTime = 0;
let tourSegmentIndex = -1;
let explodeModuleDelays = {};
let gameInitialized = false;
const gameKeys = new Set();
let gameYaw = 0;
let gamePitch = 0;
let gameTargetYaw = 0;
let gameTargetPitch = 0;
let gameSpeedValue = 0;
const gameVelocity = new THREE.Vector3();
let gamePointerLocked = false;
let gameDragging = false;
let gameCameraDistance = 390;
let gameWarpTimer = 0;
let gameWarpCooldown = 0;
let gameNavRows = [];
let gameNavTimer = 0;
let gameHudTimer = 0;
let gameBank = 0;
let gameNearestName = '';
let gameInitialPosition = new THREE.Vector3();
let elapsed = 0;
let activeView = 'station';
let cameraTween = null;
let focusAnchor = null;
let markerData = [];
let planetLabels = [];
let detailOpen = false;

function initWorld(textures) {
  earth = createEarth(textures);
  scene.add(earth.group);

  solar = createSolarSystem(textures);
  solar.group.visible = false;
  scene.add(solar.group);

  station = createStation();
  station.group.position.copy(EARTH_POSITION).add(STATION_OFFSET);
  station.group.scale.setScalar(1.34);
  scene.add(station.group);

  ship = createCruiser();
  ship.group.visible = false;
  scene.add(ship.group);

  // station docking target for the main sun/fill lights
  const stationFillTarget = new THREE.Object3D();
  stationFillTarget.position.copy(station.group.position);
  scene.add(stationFillTarget);
  fillLight.target = stationFillTarget;
  rimLight.target = stationFillTarget;

  buildMarkers();
  buildPlanetLabels();
  buildExplodeList();
  buildTourRoute();
  buildGameNav();

  camera.position.set(1450, 820, 2050);
  controls.target.copy(EARTH_POSITION);
  camera.fov = 52;
  camera.updateProjectionMatrix();

  worldReady = true;
}

/* ────────────────────────────────────────────────────────────
   camera views
   ──────────────────────────────────────────────────────────── */

const DOSSIER = {
  station: {
    title: '天穹', en: 'ORBITAL GATEWAY',
    desc: '人类首座具备恒星际跃迁能力的轨道枢纽。她停泊在晨昏线的金色边缘，等待下一次点火。',
    specs: [
      ['站体直径', '2.4 <i>KM</i>'],
      ['常住乘员', '1,280'],
      ['轨道速度', '7.66 <i>KM/S</i>'],
      ['聚变输出', '4.2 <i>TW</i>'],
    ],
  },
  earth: {
    title: '地球', en: 'EARTH · SOL III',
    desc: '人类唯一的故乡。百分之七十的蓝色表面之下，仍藏着比星图更复杂的生命网络。',
    specs: [
      ['直径', '12,742 <i>KM</i>'],
      ['轨道半径', '1.00 <i>AU</i>'],
      ['自转周期', '23H 56M'],
      ['天然卫星', '01'],
    ],
  },
  system: {
    title: '太阳系', en: 'SOL SYSTEM',
    desc: '一颗 G2V 黄矮星与八大行星组成的恒星系。天穹站正停泊在第三颗行星的近地轨道。',
    specs: [
      ['恒星', 'G2V <i>黄矮星</i>'],
      ['行星', '08'],
      ['小行星带', '2.2–3.2 <i>AU</i>'],
      ['系统年龄', '4.6 <i>BY</i>'],
    ],
  },
  cinematic: {
    title: '定速巡航', en: 'GRAND TOUR / 30 SEC',
    desc: '定速巡游程序已接管镜头。30 秒内依次掠过天穹站、太阳、水星、金星、火星、木星、土星、天王星与海王星，最后收束成整个太阳系的全景。',
    specs: [
      ['模式', 'GRAND TOUR'],
      ['周期', '30 <i>SEC</i>'],
      ['路线', '11 <i>LEGS</i>'],
      ['速度', '1.0 <i>×</i>'],
    ],
  },
  game: {
    title: '自由驾驶', en: 'FREE FLIGHT / HELIOS CRUISER',
    desc: '巡航舰驾驶权已移交。自由飞向任何行星，标记会实时投影在星图上。',
    specs: [
      ['模式', 'MANUAL'],
      ['推进', 'ION / WARP'],
      ['航线', 'FREE'],
      ['目标', 'SOL SYSTEM'],
    ],
  },
  explode: {
    title: '结构拆解', en: 'EXPLODED ASSEMBLY',
    desc: '反重力锚点已释放。所有子系统沿结构法线自动分离，实时展示这座轨道巨构的内部层次。',
    specs: [
      ['模式', 'DECON'],
      ['组件', 'ALL'],
      ['锚点', 'RELEASED'],
      ['视角', 'FREE'],
    ],
  },
};

function updateDossier(viewName) {
  const data = DOSSIER[viewName] || DOSSIER.station;
  dom.dossierTitle.textContent = data.title;
  dom.dossierEn.textContent = data.en;
  dom.dossierDesc.textContent = data.desc;
  dom.specGrid.innerHTML = data.specs
    .map(([label, value]) => `<div><span>${label}</span><b>${value}</b></div>`)
    .join('');
}

function getView(name) {
  const sp = station.group.position;
  const ep = EARTH_POSITION;
  const portrait = window.innerWidth / window.innerHeight < 0.95;
  const fit = portrait ? 1.75 : 1;

  if (name === 'earth') {
    return {
      position: new THREE.Vector3(-430 * fit, 240 * fit, 490 * fit).add(ep),
      target: new THREE.Vector3(-70, 52, 55).add(ep),
      fov: portrait ? 54 : 50,
    };
  }

  if (name === 'system') {
    return {
      position: new THREE.Vector3(0, 7600 * (portrait ? 1.6 : 1), 10500 * (portrait ? 1.6 : 1)),
      target: new THREE.Vector3(0, 0, 0),
      fov: portrait ? 58 : 50,
    };
  }

  if (name === 'cinematic') {
    return {
      position: new THREE.Vector3(-230 * fit, 85 * fit, 280 * fit).add(sp),
      target: new THREE.Vector3(-5, 6, 0).add(sp),
      fov: portrait ? 54 : 52,
    };
  }

  if (name === 'explode') {
    return {
      position: new THREE.Vector3(-310 * fit, 178 * fit, 400 * fit).add(sp),
      target: new THREE.Vector3(-34, 4, 0).add(sp),
      fov: portrait ? 58 : 50,
    };
  }

  if (query.get('closeup') === '1') {
    return {
      position: new THREE.Vector3(-96 * fit, 38 * fit, 118 * fit).add(sp),
      target: new THREE.Vector3(-5, 6, 0).add(sp),
      fov: 42,
    };
  }

  if (query.get('closeup') === '2') {
    return {
      position: new THREE.Vector3(-158 * fit, 66 * fit, 196 * fit).add(sp),
      target: new THREE.Vector3(0, -6, 0).add(sp),
      fov: 50,
    };
  }

  return {
    position: new THREE.Vector3(-168 * fit, 70 * fit, 208 * fit).add(sp),
    target: new THREE.Vector3(0, -6, 0).add(sp),
    fov: portrait ? 54 : 50,
  };
}

/* ────────────────────────────────────────────────────────────
   30-second grand tour
   ──────────────────────────────────────────────────────────── */

function buildTourRoute() {
  const planetMesh = (key) => solar.planets.find((planet) => planet.key === key)?.mesh;
  const portrait = window.innerWidth / window.innerHeight < 0.95;
  const fit = portrait ? 1.75 : 1;

  const defs = [
    { time: 0, key: 'station', name: '天穹站', target: station.group, offset: [-230, 85, 280], fov: portrait ? 54 : 52 },
    { time: 2, key: 'earth', name: '地球', target: earth.group, offset: [-360, 205, 520], fov: portrait ? 54 : 50 },
    { time: 4.5, key: 'sun', name: '太阳', target: solar.sun, offset: [0, 950, 4200], fov: portrait ? 56 : 50 },
    { time: 6.5, key: 'mercury', name: '水星', target: planetMesh('mercury'), offset: [0, 28, 88], fov: 50 },
    { time: 8.5, key: 'venus', name: '金星', target: planetMesh('venus'), offset: [0, 48, 150], fov: 50 },
    { time: 11, key: 'mars', name: '火星', target: planetMesh('mars'), offset: [0, 58, 190], fov: 50 },
    { time: 14.5, key: 'jupiter', name: '木星', target: planetMesh('jupiter'), offset: [0, 340, 1000], fov: 48 },
    { time: 17.5, key: 'saturn', name: '土星', target: planetMesh('saturn'), offset: [0, 900, 1200], fov: 46 },
    { time: 20.5, key: 'uranus', name: '天王星', target: planetMesh('uranus'), offset: [0, 230, 650], fov: 50 },
    { time: 23.5, key: 'neptune', name: '海王星', target: planetMesh('neptune'), offset: [0, 240, 680], fov: 50 },
    { time: 26.9, key: 'system', name: '太阳系', staticTarget: new THREE.Vector3(0, 0, 0), offset: [0, 7200, 10500], fov: portrait ? 58 : 50 },
    { time: 30, key: 'return', name: '天穹站', target: station.group, offset: [-230, 85, 280], fov: portrait ? 54 : 52 },
  ];

  tourWaypoints = defs.map((definition) => ({
    ...definition,
    offset: new THREE.Vector3(...definition.offset).multiplyScalar(fit),
    staticTarget: definition.staticTarget || null,
  }));
}

function waypointTarget(waypoint) {
  if (waypoint.staticTarget) return waypoint.staticTarget.clone();
  return waypoint.target.getWorldPosition(new THREE.Vector3());
}

function getTourSegment(time) {
  const normalized = ((time % 30) + 30) % 30;
  for (let i = 0; i < tourWaypoints.length - 1; i += 1) {
    const from = tourWaypoints[i];
    const to = tourWaypoints[i + 1];
    if (normalized >= from.time && normalized < to.time) {
      return { from, to, index: i, localT: (normalized - from.time) / (to.time - from.time) };
    }
  }
  const lastIndex = tourWaypoints.length - 2;
  return { from: tourWaypoints[lastIndex], to: tourWaypoints[lastIndex + 1], index: lastIndex, localT: 1 };
}

function updateTourCaption(segmentIndex) {
  if (!tourWaypoints.length) return;
  const from = tourWaypoints[segmentIndex] || tourWaypoints[0];
  let toIndex = Math.min(segmentIndex + 1, tourWaypoints.length - 1);
  while (toIndex < tourWaypoints.length - 1 && tourWaypoints[toIndex].name === from.name) toIndex += 1;
  const to = tourWaypoints[toIndex];
  dom.tourName.innerHTML = `${from.name}<span>→</span>${to.name}<i>INTERSTELLAR TRANSIT</i>`;
  dom.tourIndex.textContent = `${String(segmentIndex + 1).padStart(2, '0')} / ${String(tourWaypoints.length - 1).padStart(2, '0')}`;
}

function applyTourFrame(time) {
  if (tourWaypoints.length < 2) return;

  const { from, to, index, localT } = getTourSegment(time);
  if (index !== tourSegmentIndex) {
    tourSegmentIndex = index;
    updateTourCaption(index);
  }

  const eased = localT < 0.5
    ? 2 * localT * localT
    : 1 - Math.pow(-2 * localT + 2, 2) / 2;
  const fromTarget = waypointTarget(from);
  const toTarget = waypointTarget(to);
  const fromPosition = fromTarget.clone().add(from.offset);
  const toPosition = toTarget.clone().add(to.offset);

  const position = fromPosition.lerp(toPosition, eased);
  const target = fromTarget.lerp(toTarget, eased);
  const distance = fromPosition.distanceTo(toPosition);

  // a slow arc keeps the journey from feeling like a straight line
  const arc = Math.sin(Math.PI * localT) * Math.min(90, distance * 0.014);
  position.y += arc;

  camera.position.copy(position);
  controls.target.copy(target);
  const warpKick = Math.sin(Math.PI * localT) * Math.min(3.2, distance / 2400);
  camera.fov = THREE.MathUtils.lerp(from.fov, to.fov, eased) + warpKick;
  camera.updateProjectionMatrix();
  camera.lookAt(target);
  camera.rotateZ(Math.sin(Math.PI * localT) * 0.075 * Math.min(1, distance / 4000));
  controls.enabled = false;

  dom.tourBar.style.width = `${(time / 30) * 100}%`;

  const warp = Math.sin(Math.PI * localT) * Math.min(0.5, 0.04 + distance / 11000);
  dom.warpLines.style.opacity = warp.toFixed(3);

  let showSolar = true;
  if (index === 0 || (index === 1 && localT < 0.5)) showSolar = false;
  if (index === tourWaypoints.length - 2 && localT > 0.7) showSolar = false;
  solar.group.visible = showSolar;
}

function updateTour(delta) {
  if (tourWaypoints.length < 2) return;
  tourTime = (tourTime + delta * cruiseSpeed * cruiseDirection) % 30;
  if (tourTime < 0) tourTime += 30;
  applyTourFrame(tourTime);
}


function easeInOutCubic(t) {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

function flyTo(position, target, duration = 2.4, fov = 52, onComplete = null) {
  cameraTween = {
    fromPos: camera.position.clone(),
    toPos: position.clone(),
    fromTarget: controls.target.clone(),
    toTarget: target.clone(),
    fromFov: camera.fov,
    toFov: fov,
    t: 0,
    duration,
    onComplete,
  };
  controls.enabled = false;
}

function updateTween(delta) {
  if (!cameraTween) return;
  const tw = cameraTween;
  tw.t += delta;
  const k = Math.min(tw.t / tw.duration, 1);
  const e = easeInOutCubic(k);

  camera.position.lerpVectors(tw.fromPos, tw.toPos, e);
  controls.target.lerpVectors(tw.fromTarget, tw.toTarget, e);
  camera.fov = THREE.MathUtils.lerp(tw.fromFov, tw.toFov, e);
  camera.updateProjectionMatrix();
  camera.lookAt(controls.target);

  if (k >= 1) {
    cameraTween = null;
    controls.enabled = true;
    controls.update();
    tw.onComplete?.();
  }
}

function setActiveNav(name) {
  document.querySelectorAll('[data-view]').forEach((el) => {
    el.classList.toggle('is-active', el.dataset.view === name);
  });
}

function syncCruise() {
  dom.cruiseRate.textContent = cruiseSpeed.toFixed(1);
  if (activeView === 'cinematic') {
    const specs = dom.specGrid.querySelectorAll('b');
    if (specs[3]) specs[3].innerHTML = `${cruiseSpeed.toFixed(1)} <i>×</i>`;
  }
  dom.cruiseDir.textContent = cruiseDirection > 0 ? '↻' : '↺';
  dom.cruiseDir.classList.toggle('is-on', cruiseDirection > 0);
  dom.cruisePause.classList.toggle('is-paused', cruisePaused);
  const fill = ((cruiseSpeed - 0.2) / (3 - 0.2)) * 100;
  dom.cruiseRange.style.setProperty('--fill', `${fill}%`);

  controls.autoRotate = false;
  controls.autoRotateSpeed = 0;
  if (activeView === 'cinematic' && !cameraTween) {
    controls.enabled = cruisePaused;
    if (cruisePaused) controls.update();
  }
}

function setGameQuality(on) {
  const ratio = Math.min(window.devicePixelRatio || 1, on ? 1.0 : 1.8);
  renderer.setPixelRatio(ratio);
  composer.setPixelRatio(ratio);
  bloom.strength = on ? 0.44 : 0.82;
}

function setView(name, immediate = false) {
  if (!worldReady) return;

  activeView = name;
  setActiveNav(name);
  updateDossier(name);
  closeDetail();
  closeArchive();
  solar.group.visible = name === 'system';
  station.group.visible = true;
  earth.group.visible = name !== 'explode';
  station.setExplode(name === 'explode' ? 1 : 0);

  document.body.classList.toggle('cruise-active', name === 'cinematic');
  document.body.classList.toggle('explode-active', name === 'explode');
  document.body.classList.toggle('game-active', name === 'game');
  if (ship) ship.group.visible = false;
  setGameQuality(name === 'game');

  if (name !== 'game') gameKeys.clear();

  if (name === 'game') {
    cameraTween = null;
    controls.enabled = false;
    solar.group.visible = true;
    earth.group.visible = true;
    station.group.visible = true;
    station.setExplode(0);
    tourSegmentIndex = -1;
    dom.warpLines.style.opacity = '0';
    if (!gameInitialized) resetGame();
    else {
      const pose = gameCameraPose();
      camera.position.copy(pose.position);
      controls.target.copy(pose.target);
      camera.lookAt(controls.target);
    }
    updateGameHud();
    syncGameNav(true);
    if (!document.pointerLockElement) {
      try { canvas.requestPointerLock?.(); } catch { /* ignored */ }
    }
    return;
  }

  if (document.pointerLockElement) document.exitPointerLock?.();

  if (name === 'cinematic') {
    cruisePaused = false;
    const startAt = parseFloat(query.get('tour') || '0');
    tourTime = Number.isFinite(startAt) ? ((startAt % 30) + 30) % 30 : 0;
    tourSegmentIndex = -1;
    controls.enabled = false;
    dom.warpLines.style.opacity = '0';
    updateTourCaption(0);
  } else {
    tourSegmentIndex = -1;
    dom.warpLines.style.opacity = '0';
  }

  syncCruise();

  const view = getView(name);
  controls.minDistance = name === 'system' ? 500 : name === 'explode' ? 100 : 22;
  controls.maxDistance = name === 'system' ? 26000 : name === 'explode' ? 2200 : 1400;

  if (name === 'cinematic') {
    controls.maxDistance = 30000;
    controls.minDistance = 8;
  }

  if (immediate) {
    camera.position.copy(view.position);
    controls.target.copy(view.target);
    camera.fov = view.fov;
    camera.updateProjectionMatrix();
    camera.lookAt(controls.target);
    controls.enabled = name !== 'cinematic';
    controls.update();

    if (name === 'cinematic' && tourTime > 0.001) {
      applyTourFrame(tourTime);
    }
  } else {
    flyTo(view.position, view.target, name === 'system' ? 3.4 : name === 'cinematic' ? 1.7 : 2.7, view.fov);
  }
}


/* ────────────────────────────────────────────────────────────
   free-flight game
   ──────────────────────────────────────────────────────────── */

function buildGameNav() {
  dom.gameNav.innerHTML = '';
  gameNavRows = [];
  const destinations = [
    ...solar.labelData,
    { key: 'earth', cn: '地球', color: '#6cb6ff', anchor: earth.group },
  ];
  destinations.forEach((destination) => {
    const row = document.createElement('div');
    row.style.setProperty('--nav-color', destination.color || '#8fe9ff');
    row.innerHTML = `<span class="g-dot"></span><b>${destination.cn}</b><i>--</i>`;
    dom.gameNav.appendChild(row);
    gameNavRows.push({
      key: destination.key, name: destination.cn, anchor: destination.anchor,
      el: row, distanceEl: row.querySelector('i'),
    });
  });
}

function resetGame() {
  gameYaw = 0.82;
  gamePitch = 0;
  gameTargetYaw = gameYaw;
  gameTargetPitch = gamePitch;
  gameCameraDistance = 390;
  gameVelocity.set(0, 0, 0);
  gameSpeedValue = 0;
  gameWarpTimer = 0;
  gameWarpCooldown = 0;
  gameInitialized = true;

  const pose = gameCameraPose();
  camera.position.copy(pose.position);
  controls.target.copy(pose.target);
  camera.lookAt(controls.target);
  const facing = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), gameYaw + Math.PI / 2);
  station.group.quaternion.copy(facing);
  updateGameHud();
  syncGameNav(true);
}

function gameOrbitOffset() {
  return new THREE.Vector3(
    Math.sin(gameYaw) * Math.cos(gamePitch),
    Math.sin(gamePitch),
    Math.cos(gameYaw) * Math.cos(gamePitch)
  ).multiplyScalar(gameCameraDistance);
}

function gameCameraPose() {
  const horizontal = new THREE.Vector3(-Math.sin(gameYaw), 0, -Math.cos(gameYaw)).normalize();
  const right = new THREE.Vector3(Math.cos(gameYaw), 0, -Math.sin(gameYaw)).normalize();
  const position = station.group.position.clone()
    .addScaledVector(horizontal, -gameCameraDistance)
    .add(new THREE.Vector3(0, 80, 0));
  const lookDistance = 900;
  const target = station.group.position.clone()
    .addScaledVector(horizontal, lookDistance)
    .add(new THREE.Vector3(0, 40 + Math.tan(gamePitch) * lookDistance, 0));
  return { position, target };
}

function syncGameNav(force = false) {
  let nearest = null;
  gameNavRows.forEach((row) => {
    const world = row.anchor.getWorldPosition(new THREE.Vector3());
    const distance = station.group.position.distanceTo(world);
    row.distanceEl.textContent = `${Math.round(distance)} U`;
    if (!nearest || distance < nearest.distance) nearest = { ...row, distance };
  });
  if (nearest) dom.gameNearest.textContent = `NEAREST // ${nearest.name}`;
}

function updateGameHud() {
  if (!station) return;
  const speed = Math.round(gameSpeedValue / 10);
  dom.gameSpeed.textContent = String(speed).padStart(3, '0');
  dom.gameThrust.style.width = `${Math.min(100, (gameSpeedValue / 8500) * 100)}%`;
  const warpFill = gameWarpTimer > 0 ? 100 : Math.max(0, 100 - (gameWarpCooldown / 5) * 100);
  dom.gameWarp.style.width = `${warpFill}%`;

  if (gameWarpTimer > 0) dom.gameWarpState.textContent = 'WARP ACTIVE';
  else if (gameWarpCooldown > 0) dom.gameWarpState.textContent = `WARP CHARGE ${gameWarpCooldown.toFixed(1)}S`;
  else dom.gameWarpState.textContent = 'WARP READY';

  if (dom.gameCoords) {
    const p = station.group.position;
    dom.gameCoords.textContent = `X ${Math.round(p.x)} / Y ${Math.round(p.y)} / Z ${Math.round(p.z)}`;
  }
  if (dom.gameAttitude) {
    const hdg = (gameYaw * 180 / Math.PI % 360 + 360) % 360;
    const pitch = gamePitch * 180 / Math.PI;
    dom.gameAttitude.textContent = `HDG ${String(Math.round(hdg)).padStart(3, '0')}° · PIT ${pitch >= 0 ? '+' : ''}${Math.round(pitch)}°`;
  }
}

function triggerWarp() {
  if (gameWarpTimer > 0 || gameWarpCooldown > 0) return;
  gameWarpTimer = 1.2;
  gameWarpCooldown = 5.0;
}

function updateGame(delta) {
  if (!station) return;

  gameWarpCooldown = Math.max(0, gameWarpCooldown - delta);
  gameWarpTimer = Math.max(0, gameWarpTimer - delta);

  if (gameKeys.has('ArrowLeft')) gameTargetYaw += 0.75 * delta;
  if (gameKeys.has('ArrowRight')) gameTargetYaw -= 0.75 * delta;
  if (gameKeys.has('ArrowUp')) gameTargetPitch += 0.55 * delta;
  if (gameKeys.has('ArrowDown')) gameTargetPitch -= 0.55 * delta;
  gameTargetPitch = THREE.MathUtils.clamp(gameTargetPitch, -0.55, 0.65);

  let yawDiff = gameTargetYaw - gameYaw;
  yawDiff = Math.atan2(Math.sin(yawDiff), Math.cos(yawDiff));
  const lookSmooth = 1 - Math.exp(-22 * delta);
  gameYaw += yawDiff * lookSmooth;
  gamePitch += (gameTargetPitch - gamePitch) * lookSmooth;

  if (gameKeys.has('KeyF')) triggerWarp();

  const horizontalForward = new THREE.Vector3(-Math.sin(gameYaw), 0, -Math.cos(gameYaw)).normalize();
  const right = new THREE.Vector3(Math.cos(gameYaw), 0, -Math.sin(gameYaw)).normalize();
  const up = new THREE.Vector3(0, 1, 0);

  let forwardInput = 0;
  if (gameKeys.has('KeyW')) forwardInput += 1;
  if (gameKeys.has('KeyS')) forwardInput -= 0.45;
  let speed = 1050 * forwardInput;
  if (gameKeys.has('ShiftLeft') || gameKeys.has('ShiftRight')) speed *= 2.8;
  if (gameWarpTimer > 0) speed += 7200;

  const strafeInput = (gameKeys.has('KeyD') ? 1 : 0) - (gameKeys.has('KeyA') ? 1 : 0);
  const liftInput = (gameKeys.has('KeyE') ? 1 : 0) - (gameKeys.has('KeyQ') ? 1 : 0);
  const desiredVelocity = new THREE.Vector3()
    .addScaledVector(horizontalForward, speed)
    .addScaledVector(right, strafeInput * 320)
    .addScaledVector(up, liftInput * 230);

  gameVelocity.lerp(desiredVelocity, 1 - Math.exp(-7 * delta));
  station.group.position.addScaledVector(gameVelocity, delta);
  gameSpeedValue = gameVelocity.length();

  const facing = new THREE.Quaternion().setFromAxisAngle(
    new THREE.Vector3(0, 1, 0),
    gameYaw + Math.PI / 2
  );
  station.group.quaternion.slerp(facing, 1 - Math.exp(-7 * delta));

  const warp = gameWarpTimer > 0 ? gameWarpTimer / 1.2 : 0;
  const pose = gameCameraPose();
  const follow = 1 - Math.exp(-10 * delta);
  camera.position.lerp(pose.position, follow);
  controls.target.lerp(pose.target, follow);
  camera.lookAt(controls.target);
  camera.fov = THREE.MathUtils.lerp(camera.fov, 62 + Math.min(8, gameSpeedValue / 1000) + warp * 9, 0.2);
  camera.updateProjectionMatrix();

  dom.warpLines.style.opacity = warp > 0 ? (0.38 + warp * 0.34).toFixed(2) : '0';
  gameHudTimer += delta;
  if (gameHudTimer > 0.08) {
    gameHudTimer = 0;
    updateGameHud();
  }
  gameNavTimer += delta;
  if (gameNavTimer > 0.22) {
    gameNavTimer = 0;
    syncGameNav();
  }
}

/* ────────────────────────────────────────────────────────────
   HTML markers / planet labels
   ──────────────────────────────────────────────────────────── */

function buildMarkers() {
  dom.markers.innerHTML = '';
  markerData = [];

  station.anchors.forEach((anchor, index) => {
    const el = document.createElement('div');
    el.className = 'marker';
    el.setAttribute('role', 'button');
    el.setAttribute('tabindex', '0');
    el.innerHTML = `
      <span class="m-dot"></span>
      <span class="m-line"></span>
      <span class="m-copy"><b>${anchor.label}</b><span>${String(index + 1).padStart(2, '0')} · ${anchor.en}</span></span>
    `;
    dom.markers.appendChild(el);

    const open = () => focusModule(anchor);
    el.addEventListener('click', open);
    el.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        open();
      }
    });

    markerData.push({ el, anchor });
  });
}

function buildExplodeList() {
  dom.explodeList.innerHTML = '';
  dom.explodeParts.textContent = `PARTS ${station.partCount}`;
  explodeModuleDelays = {};

  const byKey = new Map(station.explosionModules.map((module) => [module.key, module]));
  const order = ['gate', 'solar', 'service', 'habitat', 'command', 'dock', 'radiator'];
  const labels = {
    gate: '跃迁门', solar: '聚变供能翼', service: '服务环',
    habitat: '重力居住环', command: '指挥核心', dock: '轨道对接港', radiator: '散热阵列',
  };

  const rows = order.filter((key) => byKey.has(key));
  rows.forEach((key, index) => {
    const module = byKey.get(key);
    explodeModuleDelays[key] = module.delay;
    const row = document.createElement('div');
    row.dataset.explodeKey = key;
    row.innerHTML = `<span>${String(index + 1).padStart(2, '0')}</span><b>${labels[key] || module.label}</b><i>锁定</i>`;
    dom.explodeList.appendChild(row);
  });
}

function updateExplodeHud() {
  if (!station || activeView !== 'explode') return;

  const progress = station.getExplode();
  const pct = Math.round(progress * 100);
  dom.explodePct.textContent = String(pct).padStart(3, '0');
  dom.explodeBar.style.width = `${pct}%`;
  dom.explodePanel.classList.toggle('is-complete', progress > 0.985);

  dom.explodeList.querySelectorAll('[data-explode-key]').forEach((row) => {
    const key = row.dataset.explodeKey;
    const delay = explodeModuleDelays[key] ?? 0.2;
    const rowProgress = THREE.MathUtils.clamp((progress - delay) / Math.max(0.001, 1 - delay), 0, 1);
    const status = row.querySelector('i');
    row.classList.toggle('is-separating', rowProgress > 0.04 && rowProgress < 0.94);
    row.classList.toggle('is-separated', rowProgress >= 0.94);
    status.textContent = rowProgress >= 0.94 ? '已分离' : rowProgress > 0.04 ? '分离中' : '锁定';
  });
}

function buildPlanetLabels() {
  dom.planetLabels.innerHTML = '';
  planetLabels = [];

  const all = [
    ...solar.labelData,
    { key: 'earth', cn: '地球', en: 'EARTH · HELIOS STATION', color: '#6cb6ff', anchor: earth.group, isEarth: true },
  ];
  const priority = {
    sun: 10, earth: 9, jupiter: 8, saturn: 8, mars: 6,
    uranus: 5, neptune: 5, venus: 3, mercury: 2,
  };

  all.forEach((data) => {
    const el = document.createElement('div');
    el.className = `planet-label${data.isSun ? ' sun' : ''}`;
    el.style.setProperty('--planet-color', data.color);
    el.innerHTML = `<span class="p-dot"></span><span class="p-copy"><b>${data.cn}</b><i>${data.en}</i></span>`;
    dom.planetLabels.appendChild(el);
    planetLabels.push({ el, data, priority: priority[data.key] ?? 1 });
  });
}

function toScreen(worldPosition, margin = 80) {
  const v = worldPosition.clone().project(camera);
  if (v.z < -1 || v.z > 1) return null;

  const dir = worldPosition.clone().sub(camera.position);
  if (dir.dot(camera.getWorldDirection(new THREE.Vector3())) <= 0) return null;

  const x = (v.x * 0.5 + 0.5) * window.innerWidth;
  const y = (-v.y * 0.5 + 0.5) * window.innerHeight;
  if (x < -margin || x > window.innerWidth + margin || y < -margin || y > window.innerHeight + margin) return null;
  return { x, y };
}

const tmpWorld = new THREE.Vector3();

function updateMarkers() {
  const stationVisible = worldReady && started && !detailOpen && activeView !== 'explode' && (activeView === 'station' || activeView === 'earth');
  const showDistance = station ? camera.position.distanceTo(station.group.position) < 1500 : false;

  markerData.forEach(({ el, anchor }) => {
    if (!stationVisible || !showDistance) {
      el.classList.remove('is-visible');
      return;
    }
    anchor.object.getWorldPosition(tmpWorld);
    const point = toScreen(tmpWorld, 100);
    if (!point || point.x < 50 || point.x > window.innerWidth - 80) {
      el.classList.remove('is-visible');
      return;
    }
    el.style.transform = `translate3d(${point.x.toFixed(1)}px, ${point.y.toFixed(1)}px, 0)`;
    el.classList.add('is-visible');
  });
}

function updatePlanetLabels() {
  const show = worldReady && started && (activeView === 'system' || activeView === 'game');
  if (!show) {
    planetLabels.forEach(({ el }) => el.classList.remove('is-visible'));
    return;
  }

  // highest-priority labels reserve screen space; minor planets gracefully hide
  const sorted = [...planetLabels].sort((a, b) => b.priority - a.priority);
  const placed = [];

  sorted.forEach(({ el, data }) => {
    data.anchor.getWorldPosition(tmpWorld);
    const point = toScreen(tmpWorld, 50);
    if (!point || point.x < 24 || point.x > window.innerWidth - 12) {
      el.classList.remove('is-visible');
      return;
    }

    const w = el._w || (el._w = el.offsetWidth || 120);
    const h = el._h || (el._h = el.offsetHeight || 18);
    if (point.x + w > window.innerWidth - 10) {
      el.classList.remove('is-visible');
      return;
    }
    const rect = {
      left: point.x - 4,
      right: point.x + w + 4,
      top: point.y - h * 0.5 - 4,
      bottom: point.y + h * 0.5 + 4,
    };

    const collides = placed.some((other) => (
      rect.left < other.right && rect.right > other.left
      && rect.top < other.bottom && rect.bottom > other.top
    ));

    if (collides) {
      el.classList.remove('is-visible');
      return;
    }

    placed.push(rect);
    el.style.transform = `translate3d(${point.x.toFixed(1)}px, ${point.y.toFixed(1)}px, 0)`;
    el.classList.add('is-visible');
  });
}

/* ────────────────────────────────────────────────────────────
   detail panel
   ──────────────────────────────────────────────────────────── */

function focusModule(anchor) {
  if (!worldReady || !station) return;
  focusAnchor = anchor;
  activeView = 'station';
  setActiveNav('station');
  updateDossier('station');
  controls.autoRotate = false;
  closeArchive();
  if (solar) solar.group.visible = false;
  if (station) station.group.visible = true;

  const target = new THREE.Vector3();
  anchor.object.getWorldPosition(target);

  // anchor.focusOffset is station-local; localToWorld includes the station transform
  const cameraPos = new THREE.Vector3();
  const focusScale = window.innerWidth / window.innerHeight < 0.95 ? 1.45 : 1;
  station.group.localToWorld(cameraPos.copy(anchor.focusOffset).multiplyScalar(focusScale));

  flyTo(cameraPos, target, 2.0, 46);

  dom.detailIndex.textContent = `MODULE // ${String(markerData.findIndex((m) => m.anchor === anchor) + 1).padStart(2, '0')}`;
  dom.detailTitle.textContent = anchor.label;
  dom.detailEn.textContent = anchor.en;
  dom.detailDesc.textContent = anchor.description;
  dom.detailStats.innerHTML = anchor.stats.map(([k, v]) => `<div><span>${k}</span><b>${v}</b></div>`).join('');
  dom.detail.classList.add('is-open');
  detailOpen = true;
  document.body.classList.add('detail-open');
}

function closeDetail() {
  dom.detail.classList.remove('is-open');
  detailOpen = false;
  document.body.classList.remove('detail-open');
}

function openArchive() {
  closeDetail();
  dom.archive.classList.add('is-open');
}

function closeArchive() {
  dom.archive.classList.remove('is-open');
}

/* ────────────────────────────────────────────────────────────
   intro / loading
   ──────────────────────────────────────────────────────────── */

let textureProgress = 0;
let texturesLoaded = false;
let loadingStarted = performance.now();
let readyFlagged = false;

function updateLoading() {
  const elapsedMs = performance.now() - loadingStarted;
  const timeProgress = Math.min(99, (elapsedMs / 2800) * 100);
  const target = texturesLoaded ? Math.min(100, Math.max(96, textureProgress, timeProgress)) : Math.min(92, timeProgress, textureProgress * 0.9 + 12);
  const shown = Math.min(100, Math.round(target));

  dom.loadBar.style.width = `${shown}%`;
  dom.loadPct.textContent = String(shown).padStart(2, '0');

  if (shown < 34) dom.loadStatus.textContent = '正在同步轨道参数';
  else if (shown < 64) dom.loadStatus.textContent = '正在校准聚变阵列';
  else if (shown < 92) dom.loadStatus.textContent = '正在接入深空链路';
  else dom.loadStatus.textContent = '轨道链路已建立';

  if (texturesLoaded && elapsedMs > 2400 && !readyFlagged) {
    readyFlagged = true;
    dom.loadBar.style.width = '100%';
    dom.loadPct.textContent = '100';
    dom.loadStatus.textContent = '轨道链路已建立 // 就绪';
    dom.enterBtn.disabled = false;
    dom.enterBtn.classList.add('ready');
    dom.enterBtn.querySelector('.enter-label').textContent = '进入空间站';
  }
}

function beginExperience(autostart = false) {
  if (started) return;
  started = true;
  dom.intro.classList.add('is-out');
  document.body.classList.add('live');
  dom.hud.setAttribute('aria-hidden', 'false');
  closeDetail();
  closeArchive();

  if (autostart) {
    dom.intro.style.transition = 'none';
    dom.intro.style.display = 'none';
    activeView = query.get('view') || 'station';
    if (!['station', 'earth', 'system', 'cinematic', 'explode', 'game'].includes(activeView)) activeView = 'station';
    setView(activeView, true);
    controls.enabled = true;
    return;
  }

  activeView = 'station';
  setActiveNav('station');
  const view = getView('station');
  flyTo(view.position, view.target, 5.2, view.fov);
}

dom.enterBtn.addEventListener('click', () => beginExperience(false));

/* ────────────────────────────────────────────────────────────
   UI events
   ──────────────────────────────────────────────────────────── */

document.querySelectorAll('[data-view]').forEach((el) => {
  el.addEventListener('click', () => setView(el.dataset.view));
});

document.getElementById('brandHome').addEventListener('click', () => {
  if (started) setView('station');
});

dom.detailClose.addEventListener('click', () => {
  closeDetail();
  setView('station');
});
dom.detailBack.addEventListener('click', () => {
  closeDetail();
  setView('station');
});

dom.archiveBtn.addEventListener('click', openArchive);
dom.archiveClose.addEventListener('click', closeArchive);

dom.speedRange.addEventListener('input', (e) => {
  timeScale = parseFloat(e.target.value);
  dom.speed.textContent = timeScale.toFixed(1);
  const pct = (timeScale / 4) * 100;
  dom.speedRange.style.setProperty('--fill', `${pct}%`);
});

dom.pauseBtn.addEventListener('click', () => {
  paused = !paused;
  dom.pauseBtn.classList.toggle('is-paused', paused);
});

dom.cruiseRange.addEventListener('input', (e) => {
  cruiseSpeed = parseFloat(e.target.value);
  syncCruise();
});

dom.cruiseDir.addEventListener('click', () => {
  cruiseDirection *= -1;
  syncCruise();
});

dom.cruisePause.addEventListener('click', () => {
  cruisePaused = !cruisePaused;
  syncCruise();
  if (cruisePaused) dom.warpLines.style.opacity = '0';
});

dom.recomposeBtn.addEventListener('click', () => setView('station'));

syncCruise();

dom.fullBtn.addEventListener('click', () => {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen?.().catch(() => {});
  } else {
    document.exitFullscreen?.();
  }
});

/* ambient sound */
let audio = null;
let audioOn = false;

function initAudio() {
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  if (!AudioCtx) return null;

  const ctx = new AudioCtx();
  const master = ctx.createGain();
  master.gain.value = 0;
  master.connect(ctx.destination);

  const osc1 = ctx.createOscillator();
  osc1.type = 'sine';
  osc1.frequency.value = 48;
  const osc2 = ctx.createOscillator();
  osc2.type = 'sine';
  osc2.frequency.value = 72.4;
  osc2.detune.value = 7;
  const gain1 = ctx.createGain();
  gain1.gain.value = 0.12;
  const gain2 = ctx.createGain();
  gain2.gain.value = 0.045;

  const filter = ctx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.value = 380;
  filter.Q.value = 0.8;

  osc1.connect(gain1);
  gain1.connect(filter);
  osc2.connect(gain2);
  gain2.connect(filter);
  filter.connect(master);

  const bufferSize = ctx.sampleRate * 4;
  const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const data = noiseBuffer.getChannelData(0);
  let last = 0;
  for (let i = 0; i < bufferSize; i += 1) {
    const white = Math.random() * 2 - 1;
    last = (last + 0.017 * white) / 1.017;
    data[i] = last * 2.4;
  }
  const noise = ctx.createBufferSource();
  noise.buffer = noiseBuffer;
  noise.loop = true;
  const noiseFilter = ctx.createBiquadFilter();
  noiseFilter.type = 'bandpass';
  noiseFilter.frequency.value = 130;
  noiseFilter.Q.value = 0.6;
  const noiseGain = ctx.createGain();
  noiseGain.gain.value = 0.16;
  noise.connect(noiseFilter);
  noiseFilter.connect(noiseGain);
  noiseGain.connect(master);

  osc1.start();
  osc2.start();
  noise.start();

  return { ctx, master };
}

dom.soundBtn.addEventListener('click', async () => {
  if (!audio) audio = initAudio();
  if (!audio) return;
  await audio.ctx.resume();
  audioOn = !audioOn;
  const now = audio.ctx.currentTime;
  audio.master.gain.cancelScheduledValues(now);
  audio.master.gain.setTargetAtTime(audioOn ? 0.55 : 0.0, now, 1.2);
  dom.soundBtn.classList.toggle('is-on', audioOn);
});

/* custom cursor */
if (!isCoarsePointer) {
  document.body.classList.add('cursor-live');
  window.addEventListener('mousemove', (e) => {
    dom.cursor.style.left = `${e.clientX}px`;
    dom.cursor.style.top = `${e.clientY}px`;
    dom.cursorDot.style.left = `${e.clientX}px`;
    dom.cursorDot.style.top = `${e.clientY}px`;
    const hot = e.target.closest('button, .marker');
    document.body.classList.toggle('cursor-hot', !!hot);
  }, { passive: true });
}

let lastPortrait = window.innerWidth / window.innerHeight < 0.95;

/* resize */
function onResize() {
  const w = window.innerWidth;
  const h = window.innerHeight;
  const portrait = w / h < 0.95;
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  const ratio = Math.min(window.devicePixelRatio || 1, activeView === 'game' ? 1.0 : 1.8);
  renderer.setPixelRatio(ratio);
  renderer.setSize(w, h);
  composer.setPixelRatio(ratio);
  composer.setSize(w, h);
  bloom.setSize(w, h);

  if (started && !cameraTween && portrait !== lastPortrait) {
    setView(activeView, true);
  }
  lastPortrait = portrait;
}
window.addEventListener('resize', onResize);

document.addEventListener('fullscreenchange', () => {
  dom.fullBtn.classList.toggle('is-on', !!document.fullscreenElement);
});

/* ────────────────────────────────────────────────────────────
   animation
   ──────────────────────────────────────────────────────────── */

if (query.get('debug') === '1') {
  window.__HELIOS = {
    setView,
    setTourTime(time) {
      cruisePaused = true;
      tourTime = ((time % 30) + 30) % 30;
      applyTourFrame(tourTime);
      syncCruise();
    },
    resume() {
      cruisePaused = false;
      syncCruise();
    },
    state() {
      return {
        activeView,
        tourTime,
        tourSegmentIndex,
        camera: camera.position.toArray(),
        target: controls.target.toArray(),
        solarVisible: solar?.group.visible,
        stationVisible: station?.group.visible,
      };
    },
  };
}

const clockObj = new THREE.Clock();
let fpsAccum = 0;
let fpsFrames = 0;
let fpsLast = 0;
let uiTimer = 0;

function animate() {
  const rawDelta = Math.min(clockObj.getDelta(), 0.2);
  elapsed += rawDelta;

  starfield.update(elapsed);

  if (worldReady) {
    const worldDelta = paused ? 0 : rawDelta * timeScale;

    earth.update(rawDelta, paused ? 0 : timeScale);
    solar.update(rawDelta, paused ? 0 : timeScale);
    if (activeView !== 'game') {
      station.update(rawDelta, paused ? 0 : timeScale);
    }

    // keep the station visible while pulling away, then drop it once it is a speck
    const distanceToStation = camera.position.distanceTo(station.group.position);
    if (activeView === 'game') {
      station.group.visible = true;
    } else if (activeView === 'cinematic') {
      station.group.visible = distanceToStation < 3000;
    } else if (activeView === 'system') {
      station.group.visible = distanceToStation < 1400;
    } else {
      station.group.visible = true;
    }

    if (cameraTween) {
      updateTween(rawDelta);
    } else if (activeView === 'game') {
      updateGame(rawDelta);
    } else if (activeView === 'cinematic') {
      if (cruisePaused) {
        controls.enabled = true;
        controls.update();
      } else {
        controls.enabled = false;
        updateTour(rawDelta);
      }
    } else {
      controls.update();
    }
    updateMarkers();
    updatePlanetLabels();
    updateExplodeHud();
  } else {
    controls.update();
  }

  // gentle intro drift
  if (!started && worldReady) {
    const drift = Math.sin(elapsed * 0.08) * 30;
    camera.position.x = 1450 + drift;
    camera.position.y = 820 + Math.sin(elapsed * 0.11) * 18;
    camera.lookAt(controls.target);
  }

  composer.render();

  // ui telemetry
  fpsAccum += rawDelta;
  fpsFrames += 1;
  uiTimer += rawDelta;
  if (uiTimer > 0.35) {
    uiTimer = 0;
    const fps = Math.round(fpsFrames / Math.max(fpsAccum, 0.001));
    fpsAccum = 0;
    fpsFrames = 0;
    dom.fps.textContent = String(Math.min(999, fps));
    dom.alt.textContent = `${(412.5 + Math.sin(elapsed * 0.7) * 0.18).toFixed(2)} KM`;
    dom.vel.textContent = `${(7.66 + Math.sin(elapsed * 0.43) * 0.002).toFixed(3)} KM/S`;

    const total = Math.floor(elapsed);
    const hh = String(Math.floor(total / 3600)).padStart(2, '0');
    const mm = String(Math.floor((total % 3600) / 60)).padStart(2, '0');
    const ss = String(total % 60).padStart(2, '0');
    dom.clock.textContent = `T+ ${hh}:${mm}:${ss}`;
  }

  updateLoading();
  requestAnimationFrame(animate);
}

/* ────────────────────────────────────────────────────────────
   boot
   ──────────────────────────────────────────────────────────── */

loadTextures((pct) => {
  textureProgress = pct;
}, renderer.capabilities.getMaxAnisotropy()).then((textures) => {
  texturesLoaded = true;
  textureProgress = 100;
  try {
    initWorld(textures);
  } catch (error) {
    console.error('HELIOS world init failed:', error);
    dom.loadStatus.textContent = '渲染链路异常 · 请查看控制台';
  }

  if (query.get('autostart') === '1') {
    dom.loadBar.style.width = '100%';
    dom.loadPct.textContent = '100';
    dom.loadStatus.textContent = '轨道链路已建立 // 就绪';
    dom.enterBtn.disabled = false;
    setTimeout(() => beginExperience(true), 120);
  }
});

// make the title screen responsive to Enter
window.addEventListener('keydown', (e) => {
  if (e.target && ['INPUT', 'TEXTAREA'].includes(e.target.tagName)) return;

  if (e.key === 'Enter' && !started && !dom.enterBtn.disabled) beginExperience(false);
  if (e.key === 'Escape') {
    if (detailOpen) setView('station');
    closeDetail();
    closeArchive();
  }

  if (!started) return;
  if (e.key === '1') setView('station');
  if (e.key === '2') setView('earth');
  if (e.key === '3') setView('system');
  if (e.key === '4') setView('explode');
  if (e.key === '5') setView('game');

  if (activeView === 'game') {
    const gameCodes = ['KeyW', 'KeyA', 'KeyS', 'KeyD', 'KeyQ', 'KeyE',
      'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ShiftLeft', 'ShiftRight', 'KeyF'];
    if (gameCodes.includes(e.code)) {
      e.preventDefault();
      gameKeys.add(e.code);
      if (e.code === 'KeyF') triggerWarp();
    }
  }

  if (e.key === ' ') {
    e.preventDefault();
    dom.pauseBtn.click();
  }
  if (e.key.toLowerCase() === 'f' && activeView !== 'game') dom.fullBtn.click();
  if (e.key.toLowerCase() === 'm') dom.soundBtn.click();
});

window.addEventListener('keyup', (e) => {
  gameKeys.delete(e.code);
});

window.addEventListener('blur', () => gameKeys.clear());

dom.gameWarpBtn.addEventListener('click', () => {
  if (activeView === 'game') triggerWarp();
});

canvas.addEventListener('mousedown', () => {
  if (activeView !== 'game') return;
  gameDragging = true;
  if (!document.pointerLockElement) canvas.requestPointerLock?.();
});

window.addEventListener('mouseup', () => {
  gameDragging = false;
});

window.addEventListener('wheel', (event) => {
  if (activeView !== 'game') return;
  event.preventDefault();
  gameCameraDistance = THREE.MathUtils.clamp(gameCameraDistance + event.deltaY * 0.35, 280, 980);
}, { passive: false });

document.addEventListener('mousemove', (event) => {
  if (activeView !== 'game') return;
  const locked = document.pointerLockElement === canvas;
  if (!locked && !gameDragging) return;
  gameTargetYaw -= event.movementX * 0.0021;
  gameTargetPitch -= event.movementY * 0.0021;
  gameTargetPitch = THREE.MathUtils.clamp(gameTargetPitch, -0.55, 0.65);
});

document.addEventListener('pointerlockchange', () => {
  gamePointerLocked = document.pointerLockElement === canvas;
  document.body.classList.toggle('pointer-locked', gamePointerLocked);
  if (dom.gameLock) {
    dom.gameLock.textContent = gamePointerLocked
      ? '鼠标已锁定 · ESC 释放 · 点击画面重新锁定'
      : '点击画面锁定鼠标 · 拖动画面也可观察';
  }
});

animate();
