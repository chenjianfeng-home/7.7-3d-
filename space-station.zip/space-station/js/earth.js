import * as THREE from 'three';

const EARTH_RADIUS = 90;
const EARTH_POSITION = new THREE.Vector3(2800, 0, 0);

const earthVertex = /* glsl */`
  varying vec2 vUv;
  varying vec3 vNormalW;
  varying vec3 vPositionW;

  void main() {
    vUv = uv;
    vNormalW = normalize(mat3(modelMatrix) * normal);
    vec4 world = modelMatrix * vec4(position, 1.0);
    vPositionW = world.xyz;
    gl_Position = projectionMatrix * viewMatrix * world;
  }
`;

const earthFragment = /* glsl */`
  precision highp float;

  uniform sampler2D dayMap;
  uniform sampler2D nightMap;
  uniform sampler2D cloudsMap;
  uniform sampler2D normalMap;
  uniform sampler2D specMap;
  uniform vec3 sunDirection;
  uniform float time;

  varying vec2 vUv;
  varying vec3 vNormalW;
  varying vec3 vPositionW;

  void main() {
    vec3 N = normalize(vNormalW);
    vec3 T = normalize(cross(vec3(0.0, 1.0, 0.0), N));
    vec3 B = normalize(cross(N, T));
    vec3 nTex = texture2D(normalMap, vUv).xyz * 2.0 - 1.0;
    N = normalize(T * nTex.x * 0.55 + B * nTex.y * 0.55 + N);

    vec3 L = normalize(sunDirection);
    vec3 V = normalize(cameraPosition - vPositionW);
    float ndl = dot(N, L);
    float day = smoothstep(-0.16, 0.24, ndl);

    vec3 dayColor = texture2D(dayMap, vUv).rgb;
    vec3 nightColor = texture2D(nightMap, vUv).rgb;

    // warm city lights, strongest just after sunset
    float city = smoothstep(0.02, 0.42, 1.0 - day) * smoothstep(-0.25, 0.08, ndl);
    vec3 lights = nightColor * vec3(1.35, 0.92, 0.52) * (0.55 + city * 2.1);

    float lit = max(ndl, 0.0);
    vec3 surface = dayColor * (0.07 + lit * 1.02);
    surface = mix(surface, dayColor * 0.045 + lights, smoothstep(0.12, 0.88, 1.0 - day));

    // ocean sun glint
    float ocean = texture2D(specMap, vUv).r;
    vec3 H = normalize(L + V);
    float spec = pow(max(dot(N, H), 0.0), 96.0) * ocean * smoothstep(0.0, 0.3, ndl);
    surface += vec3(1.0, 0.84, 0.62) * spec * 0.55;

    // cloud shadows + sunlit cloud deck
    float cloud = texture2D(cloudsMap, vUv + vec2(time * 0.00065, 0.0)).r;
    surface *= 1.0 - cloud * 0.3 * day;
    surface = mix(surface, vec3(0.86, 0.92, 1.0) * (0.035 + lit * 0.98), cloud * 0.28 * day);

    // thin atmospheric rim
    float fres = pow(1.0 - max(dot(N, V), 0.0), 3.2);
    surface += vec3(0.14, 0.42, 0.9) * fres * (0.12 + day * 0.5);

    // sunset line
    float terminator = exp(-pow(ndl / 0.16, 2.0));
    surface += vec3(1.0, 0.35, 0.1) * terminator * 0.11 * smoothstep(-0.35, 0.15, ndl);

    gl_FragColor = vec4(surface, 1.0);
  }
`;

const cloudVertex = /* glsl */`
  varying vec2 vUv;
  varying vec3 vNormalW;
  varying vec3 vPositionW;

  void main() {
    vUv = uv;
    vNormalW = normalize(mat3(modelMatrix) * normal);
    vec4 world = modelMatrix * vec4(position, 1.0);
    vPositionW = world.xyz;
    gl_Position = projectionMatrix * viewMatrix * world;
  }
`;

const cloudFragment = /* glsl */`
  precision highp float;
  uniform sampler2D map;
  uniform vec3 sunDirection;
  uniform float time;
  varying vec2 vUv;
  varying vec3 vNormalW;
  varying vec3 vPositionW;

  void main() {
    vec3 N = normalize(vNormalW);
    float ndl = max(dot(N, normalize(sunDirection)), 0.0);
    vec4 tex = texture2D(map, vUv + vec2(time * 0.0012, 0.0));
    float clouds = max(max(tex.r, tex.g), tex.b);
    float alpha = clouds * (0.08 + ndl * 0.76);
    vec3 col = mix(vec3(0.035, 0.07, 0.13), vec3(0.99, 0.98, 0.97), pow(ndl, 0.65));
    gl_FragColor = vec4(col, alpha * 0.7);
  }
`;

const atmosphereVertex = /* glsl */`
  varying vec3 vNormalV;
  varying vec3 vPositionV;
  varying vec3 vNormalW;

  void main() {
    vNormalV = normalize(normalMatrix * normal);
    vNormalW = normalize(mat3(modelMatrix) * normal);
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    vPositionV = mv.xyz;
    gl_Position = projectionMatrix * mv;
  }
`;

const atmosphereFragment = /* glsl */`
  precision highp float;
  uniform vec3 sunDirection;
  varying vec3 vNormalV;
  varying vec3 vPositionV;
  varying vec3 vNormalW;

  void main() {
    vec3 viewDir = normalize(-vPositionV);
    float rim = pow(1.0 - abs(dot(normalize(vNormalV), viewDir)), 2.4);
    float sun = max(dot(normalize(vNormalW), normalize(sunDirection)), 0.0);
    float intensity = rim * (0.22 + sun * 0.72);
    vec3 color = mix(vec3(0.1, 0.34, 0.95), vec3(0.62, 0.9, 1.0), rim);
    gl_FragColor = vec4(color * intensity * 0.95, intensity * 0.65);
  }
`;

function makeGlowTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.18, 'rgba(190,235,255,0.8)');
  g.addColorStop(0.48, 'rgba(100,180,255,0.22)');
  g.addColorStop(1, 'rgba(40,80,160,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 128, 128);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export function createEarth(textures, radius = EARTH_RADIUS) {
  const group = new THREE.Group();
  group.position.copy(EARTH_POSITION);
  group.name = 'EARTH';

  const tilt = new THREE.Group();
  tilt.rotation.z = THREE.MathUtils.degToRad(23.44);
  group.add(tilt);

  const sunDirection = new THREE.Vector3(-1, 0.07, 0.13).normalize();

  const uniforms = {
    dayMap: { value: textures.earthDay },
    nightMap: { value: textures.earthNight },
    cloudsMap: { value: textures.earthClouds },
    normalMap: { value: textures.earthNormal },
    specMap: { value: textures.earthSpec },
    sunDirection: { value: sunDirection },
    time: { value: 0 },
  };

  const earthMaterial = new THREE.ShaderMaterial({
    uniforms,
    vertexShader: earthVertex,
    fragmentShader: earthFragment,
  });

  const earthMesh = new THREE.Mesh(
    new THREE.SphereGeometry(radius, 128, 96),
    earthMaterial
  );
  earthMesh.rotation.y = -1.2;
  tilt.add(earthMesh);

  const cloudUniforms = {
    map: { value: textures.earthClouds },
    sunDirection: { value: sunDirection },
    time: { value: 0 },
  };
  const clouds = new THREE.Mesh(
    new THREE.SphereGeometry(radius * 1.012, 96, 64),
    new THREE.ShaderMaterial({
      uniforms: cloudUniforms,
      vertexShader: cloudVertex,
      fragmentShader: cloudFragment,
      transparent: true,
      depthWrite: false,
      blending: THREE.NormalBlending,
    })
  );
  clouds.rotation.y = -1.2;
  tilt.add(clouds);

  const atmosphere = new THREE.Mesh(
    new THREE.SphereGeometry(radius * 1.09, 96, 64),
    new THREE.ShaderMaterial({
      uniforms: { sunDirection: { value: sunDirection } },
      vertexShader: atmosphereVertex,
      fragmentShader: atmosphereFragment,
      side: THREE.BackSide,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    })
  );
  group.add(atmosphere);

  // soft blue halo that reads even at a distance
  const halo = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: makeGlowTexture(),
      color: 0x2f7dff,
      transparent: true,
      opacity: 0.16,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      depthTest: true,
    })
  );
  halo.scale.setScalar(radius * 3.6);
  group.add(halo);

  // moon
  const moonOrbit = new THREE.Group();
  moonOrbit.rotation.x = THREE.MathUtils.degToRad(12);
  moonOrbit.rotation.z = THREE.MathUtils.degToRad(-9);
  group.add(moonOrbit);

  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(radius * 0.24, 48, 32),
    new THREE.MeshStandardMaterial({
      map: textures.moon,
      roughness: 0.98,
      metalness: 0.0,
      color: 0xbfc4cc,
    })
  );
  moon.position.set(radius * 6.1, 0, 0);
  moonOrbit.add(moon);
  moonOrbit.rotation.y = 2.1;

  const moonLight = new THREE.PointLight(0xbddfff, 18, 90, 2);
  moon.add(moonLight);

  let elapsed = 0;

  function update(delta, timeScale = 1) {
    const d = delta * timeScale;
    elapsed += d;
    earthMesh.rotation.y += d * 0.012;
    clouds.rotation.y += d * 0.016;
    moonOrbit.rotation.y += d * 0.028;
    moon.rotation.y += d * 0.02;
    uniforms.time.value = elapsed;
    cloudUniforms.time.value = elapsed;
    halo.material.opacity = 0.14 + Math.sin(elapsed * 0.22) * 0.018;
  }

  return {
    group,
    radius,
    earthMesh,
    clouds,
    moon,
    sunDirection,
    update,
    position: group.position,
  };
}
