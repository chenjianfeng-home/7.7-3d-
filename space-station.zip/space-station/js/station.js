import * as THREE from 'three';

/* ═══════════════════════════════════════════════════════════
   HELIOS ORBITAL GATEWAY
   Procedural hard-surface assembly. Everything is built from
   primitives on purpose: no external model, full control.
   ═══════════════════════════════════════════════════════════ */

const DEG = Math.PI / 180;
const Y_AXIS = new THREE.Vector3(0, 1, 0);

function mulberry32(seed) {
  let a = seed;
  return function random() {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function beam(parent, a, b, radius, material, radialSegments = 8) {
  const dir = new THREE.Vector3().subVectors(b, a);
  const length = dir.length();
  const mesh = new THREE.Mesh(
    new THREE.CylinderGeometry(radius, radius, length, radialSegments, 1, false),
    material
  );
  mesh.position.copy(a).addScaledVector(dir, 0.5);
  mesh.quaternion.setFromUnitVectors(Y_AXIS, dir.normalize());
  parent.add(mesh);
  return mesh;
}

function box(parent, w, h, d, material, x = 0, y = 0, z = 0) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
  mesh.position.set(x, y, z);
  parent.add(mesh);
  return mesh;
}

function cylinder(parent, radiusTop, radiusBottom, height, material, x = 0, y = 0, z = 0, segments = 24) {
  const mesh = new THREE.Mesh(
    new THREE.CylinderGeometry(radiusTop, radiusBottom, height, segments),
    material
  );
  mesh.position.set(x, y, z);
  parent.add(mesh);
  return mesh;
}

function torus(parent, radius, tube, material, segments = 64, tubeSegments = 10) {
  const mesh = new THREE.Mesh(new THREE.TorusGeometry(radius, tube, tubeSegments, segments), material);
  parent.add(mesh);
  return mesh;
}

function glowSprite(texture, color, scale) {
  const sprite = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: texture,
      color,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
  sprite.scale.setScalar(scale);
  return sprite;
}

function makeGlowTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.15, 'rgba(230,252,255,0.9)');
  g.addColorStop(0.4, 'rgba(120,220,255,0.24)');
  g.addColorStop(1, 'rgba(60,140,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 128, 128);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function makeHullPanelTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#8a8a8a';
  ctx.fillRect(0, 0, 1024, 1024);

  const rand = mulberry32(9091);
  for (let i = 0; i < 260; i += 1) {
    const w = 20 + rand() * 160;
    const h = 12 + rand() * 90;
    const x = rand() * 1024;
    const y = rand() * 1024;
    const tone = 104 + Math.floor(rand() * 55);
    ctx.fillStyle = `rgba(${tone},${tone},${tone},0.18)`;
    ctx.fillRect(x, y, w, h);
  }

  ctx.strokeStyle = 'rgba(35,35,35,0.72)';
  ctx.lineWidth = 2;
  for (let x = 0; x <= 1024; x += 64) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 1024);
    ctx.stroke();
  }
  for (let y = 0; y <= 1024; y += 64) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(1024, y);
    ctx.stroke();
  }

  ctx.strokeStyle = 'rgba(30,30,30,0.35)';
  ctx.lineWidth = 1;
  for (let x = 0; x <= 1024; x += 16) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 1024);
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(2.2, 2.2);
  texture.anisotropy = 8;
  return texture;
}

function makeHazardTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 64;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, 512, 64);
  ctx.fillStyle = '#0b0e12';
  ctx.fillRect(0, 0, 512, 64);
  ctx.strokeStyle = 'rgba(255,180,70,0.9)';
  ctx.lineWidth = 13;
  for (let x = -80; x < 600; x += 48) {
    ctx.beginPath();
    ctx.moveTo(x, 64);
    ctx.lineTo(x + 48, 0);
    ctx.stroke();
  }
  ctx.strokeStyle = 'rgba(255,255,255,0.36)';
  ctx.lineWidth = 2;
  ctx.strokeRect(1, 1, 510, 62);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 8;
  return texture;
}

function makeDecalTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 2048;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  ctx.strokeStyle = 'rgba(180,225,255,0.38)';
  ctx.lineWidth = 3;
  ctx.strokeRect(22, 22, canvas.width - 44, canvas.height - 44);

  ctx.fillStyle = 'rgba(228,245,255,0.92)';
  ctx.font = '600 190px Bahnschrift, Segoe UI, sans-serif';
  ctx.letterSpacing = '20px';
  ctx.fillText('HELIOS', 72, 236);

  ctx.fillStyle = 'rgba(143,233,255,0.92)';
  ctx.font = '300 52px "Microsoft YaHei", sans-serif';
  ctx.letterSpacing = '26px';
  ctx.fillText('天 穹 · 轨 道 枢 纽', 80, 322);

  ctx.fillStyle = 'rgba(155,180,205,0.6)';
  ctx.font = '32px Consolas, monospace';
  ctx.letterSpacing = '6px';
  ctx.fillText('HOG-01  /  DEEP SPACE OPERATIONS', 80, 402);

  ctx.fillStyle = 'rgba(143,233,255,0.7)';
  ctx.font = '28px Consolas, monospace';
  ctx.letterSpacing = '4px';
  ctx.fillText('2149', 1770, 410);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 8;
  return texture;
}

function makeSolarMaterial() {
  return new THREE.ShaderMaterial({
    uniforms: {},
    vertexShader: /* glsl */`
      varying vec3 vPos;
      varying vec3 vNormalV;
      varying vec3 vWorld;
      varying vec3 vNormalW;
      void main() {
        vPos = position;
        vNormalV = normalize(normalMatrix * normal);
        vNormalW = normalize(mat3(modelMatrix) * normal);
        vec4 world = modelMatrix * vec4(position, 1.0);
        vWorld = world.xyz;
        gl_Position = projectionMatrix * viewMatrix * world;
      }
    `,
    fragmentShader: /* glsl */`
      precision highp float;
      varying vec3 vPos;
      varying vec3 vNormalV;
      varying vec3 vWorld;
      varying vec3 vNormalW;

      void main() {
        float gx = smoothstep(0.945, 0.99, abs(sin(vPos.z * 2.6)));
        float gy = smoothstep(0.955, 0.995, abs(sin(vPos.y * 3.1)));
        float grid = max(gx, gy);
        float border = smoothstep(0.0, 0.6, 0.5 - abs(vPos.y) / 7.0);
        vec3 deep = vec3(0.002, 0.009, 0.03);
        vec3 cell = vec3(0.006, 0.032, 0.1);
        vec3 col = mix(deep, cell, 0.4 + 0.2 * sin(vPos.z * 0.45));
        col += vec3(0.03, 0.13, 0.34) * grid * 0.34;
        col += vec3(0.01, 0.04, 0.12) * border;
        float edge = smoothstep(6.4, 7.0, abs(vPos.y)) + smoothstep(14.0, 15.0, abs(vPos.z));
        col = mix(col, vec3(0.08, 0.11, 0.14), clamp(edge, 0.0, 1.0));
        vec3 V = normalize(cameraPosition - vWorld);
        float sheen = pow(1.0 - abs(dot(normalize(vNormalW), V)), 2.8);
        col += vec3(0.015, 0.07, 0.19) * sheen;
        float sunFacing = max(dot(normalize(vNormalW), normalize(vec3(-1.0, 0.06, 0.1))), 0.0);
        col *= 0.6 + sunFacing * 1.5;
        gl_FragColor = vec4(col, 1.0);
      }
    `,
    side: THREE.DoubleSide,
  });
}

export function createStation() {
  const group = new THREE.Group();
  group.name = 'HELIOS_STATION';

  const random = mulberry32(214907);
  const hullPanelTexture = makeHullPanelTexture();
  const hazardTexture = makeHazardTexture();

  const hull = new THREE.MeshStandardMaterial({
    color: 0xa4aeba, metalness: 0.9, roughness: 0.38, envMapIntensity: 1.2,
  });
  const hullLight = new THREE.MeshStandardMaterial({
    color: 0xc7cfd9, metalness: 0.6, roughness: 0.46, envMapIntensity: 1.0,
  });
  const commandHull = new THREE.MeshStandardMaterial({
    color: 0xc3cbd5, metalness: 0.65, roughness: 0.52, envMapIntensity: 0.8,
  });
  const hullDark = new THREE.MeshStandardMaterial({
    color: 0x323b46, metalness: 0.88, roughness: 0.4, envMapIntensity: 1.2,
  });

  [hull, hullLight, commandHull, hullDark].forEach((material, i) => {
    material.bumpMap = hullPanelTexture;
    material.bumpScale = i === 3 ? 0.035 : 0.055;
    material.needsUpdate = true;
  });
  const hullBlack = new THREE.MeshStandardMaterial({
    color: 0x141a22, metalness: 0.8, roughness: 0.52,
  });
  const gold = new THREE.MeshStandardMaterial({
    color: 0xa77b3f, metalness: 1.0, roughness: 0.28, envMapIntensity: 1.8,
  });
  const copper = new THREE.MeshStandardMaterial({
    color: 0x7d5135, metalness: 0.95, roughness: 0.36,
  });
  const white = new THREE.MeshStandardMaterial({
    color: 0xe1e6ec, metalness: 0.2, roughness: 0.62,
  });
  const glowCyan = new THREE.MeshBasicMaterial({
    color: new THREE.Color(0x7fe7ff).multiplyScalar(2.8),
    toneMapped: false,
  });
  const glowWarm = new THREE.MeshBasicMaterial({
    color: new THREE.Color(0xffb066).multiplyScalar(2.4),
    toneMapped: false,
  });
  const glowWhite = new THREE.MeshBasicMaterial({
    color: new THREE.Color(0xdff6ff).multiplyScalar(2.0),
    toneMapped: false,
  });
  const solarMaterial = makeSolarMaterial();
  const glowTexture = makeGlowTexture();

  const beacons = [];
  const anchors = [];
  const lightAnchors = [];
  const explosionModules = [];

  function registerExplosionModule(object, key, label, offset, delay = 0.15) {
    explosionModules.push({
      object,
      key,
      label,
      offset: new THREE.Vector3(offset[0], offset[1], offset[2]),
      delay,
      basePosition: object.position.clone(),
    });
  }

  /* ── central spine ─────────────────────────────────────── */

  const spine = cylinder(group, 2.35, 2.35, 88, hull, 0, 0, 0, 40);
  spine.rotation.z = Math.PI / 2;

  const spineCore = cylinder(group, 1.2, 1.2, 92, hullDark, 0, 0, 0, 24);
  spineCore.rotation.z = Math.PI / 2;

  for (let x = -40; x <= 40; x += 6.5) {
    const ring = torus(group, 2.72, 0.3, x % 13 === 0 ? gold : hullDark, 40, 8);
    ring.rotation.y = Math.PI / 2;
    ring.position.x = x;
  }

  // longitudinal service conduits
  for (let i = 0; i < 4; i += 1) {
    const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
    const y = Math.cos(a) * 2.65;
    const z = Math.sin(a) * 2.65;
    beam(group, new THREE.Vector3(-40, y, z), new THREE.Vector3(31, y, z), 0.16, i % 2 ? gold : hullDark, 6);
  }

  // spine greebles
  for (let i = 0; i < 130; i += 1) {
    const x = -39 + random() * 78;
    const a = random() * Math.PI * 2;
    const r = 2.9 + random() * 0.65;
    const w = 0.25 + random() * 1.5;
    const h = 0.15 + random() * 0.75;
    const d = 0.2 + random() * 0.9;
    const material = random() > 0.82 ? gold : random() > 0.5 ? hullDark : hullLight;
    const g = box(group, w, h, d, material, x, Math.cos(a) * r, Math.sin(a) * r);
    g.rotation.x = a;
  }

  // spine light strip
  const stripA = box(group, 66, 0.08, 0.08, glowCyan, 2, 2.95, 0);
  stripA.rotation.x = 0.35;
  const stripB = box(group, 66, 0.08, 0.08, glowCyan, 2, -2.95, 0);
  stripB.rotation.x = -0.35;

  // gold thermal collars
  const collarA = cylinder(group, 2.62, 2.62, 2.2, gold, 14, 0, 0, 32);
  collarA.rotation.z = Math.PI / 2;
  const collarB = cylinder(group, 2.62, 2.62, 1.4, copper, -27, 0, 0, 32);
  collarB.rotation.z = Math.PI / 2;
  const collarC = cylinder(group, 2.78, 2.78, 0.5, gold, 8.5, 0, 0, 32);
  collarC.rotation.z = Math.PI / 2;

  /* ── structural truss ──────────────────────────────────── */

  const trussStart = -36;
  const trussEnd = 34;
  const railY = 4.5;
  const railZ = 4.5;
  const rails = [
    [railY, railZ], [railY, -railZ], [-railY, railZ], [-railY, -railZ],
  ];
  rails.forEach(([y, z]) => {
    beam(group, new THREE.Vector3(trussStart, y, z), new THREE.Vector3(trussEnd, y, z), 0.22, hullDark, 6);
  });

  for (let x = trussStart; x < trussEnd; x += 6) {
    const x2 = x + 6;
    const ringPoints = [
      new THREE.Vector3(x, railY, railZ),
      new THREE.Vector3(x, railY, -railZ),
      new THREE.Vector3(x, -railY, -railZ),
      new THREE.Vector3(x, -railY, railZ),
    ];
    for (let i = 0; i < 4; i += 1) {
      const p1 = ringPoints[i];
      const p2 = ringPoints[(i + 1) % 4];
      beam(group, p1, p2, 0.09, hullDark, 4);
      const p3 = ringPoints[(i + 1) % 4].clone();
      p3.x = x2;
      const p4 = ringPoints[(i + 2) % 4].clone();
      p4.x = x2;
      beam(group, i % 2 ? p1 : p3, i % 2 ? p4 : p2, 0.08, hull, 4);
    }
  }

  /* ── command core ──────────────────────────────────────── */

  const command = new THREE.Group();
  command.position.x = 41;
  group.add(command);
  registerExplosionModule(command, 'command', '指挥核心', [96, 28, 8], 0.46);

  const cmdSphere = new THREE.Mesh(new THREE.SphereGeometry(7.1, 56, 36), commandHull);
  cmdSphere.scale.set(1.55, 1.0, 1.0);
  command.add(cmdSphere);

  const cmdBand = torus(command, 6.2, 0.55, hullDark, 64, 10);
  cmdBand.rotation.y = Math.PI / 2;
  cmdBand.position.x = 7.2;

  const cmdWindowRing = torus(command, 4.7, 0.18, glowCyan, 64, 8);
  cmdWindowRing.rotation.y = Math.PI / 2;
  cmdWindowRing.position.x = 9.2;

  for (let i = 0; i < 20; i += 1) {
    const a = (i / 20) * Math.PI * 2;
    const win = box(command, 0.32, 0.7, 0.45, i % 4 === 0 ? glowWarm : glowCyan,
      10.15, Math.cos(a) * 4.55, Math.sin(a) * 4.55);
    win.rotation.x = -a;
  }

  const nose = cylinder(command, 2.2, 3.2, 4.8, hullDark, 12.8, 0, 0, 24);
  nose.rotation.z = Math.PI / 2;
  const noseRing = torus(command, 3.1, 0.32, gold, 40, 8);
  noseRing.rotation.y = Math.PI / 2;
  noseRing.position.x = 15.1;
  const noseGlow = cylinder(command, 1.2, 1.2, 0.2, glowCyan, 15.35, 0, 0, 24);
  noseGlow.rotation.z = Math.PI / 2;

  // command sensor cluster
  const mast = cylinder(command, 0.22, 0.28, 5.2, hullDark, 2, 7.4, 0, 8);
  const mastTip = box(command, 0.8, 0.8, 0.8, gold, 2, 10.1, 0);
  mastTip.rotation.y = Math.PI / 4;
  const mastGlow = glowSprite(glowTexture, 0x9ff4ff, 4.2);
  mastGlow.position.set(2, 10.6, 0);
  command.add(mastGlow);
  beacons.push({ sprite: mastGlow, speed: 1.2, phase: 0.2, base: 3.4 });

  // gold foil collar
  for (let i = 0; i < 6; i += 1) {
    const a = (i / 6) * Math.PI * 2;
    const foil = box(command, 1.4, 0.28, 1.1, gold, -4.2, Math.cos(a) * 6.1, Math.sin(a) * 6.1);
    foil.rotation.x = a;
  }

  /* ── hull name plates ─────────────────────────────────── */

  const decalTexture = makeDecalTexture();
  const decalMat = new THREE.MeshBasicMaterial({
    map: decalTexture,
    transparent: true,
    depthWrite: false,
    toneMapped: false,
    opacity: 0.93,
  });
  const plateA = box(group, 17.5, 4.4, 0.22, hullBlack, 21, 0, 3.25);
  plateA.rotation.z = 0;
  const decalA = new THREE.Mesh(new THREE.PlaneGeometry(17, 4.25), decalMat);
  decalA.position.set(21, 0, 3.38);
  group.add(decalA);

  const plateB = box(group, 17.5, 4.4, 0.22, hullBlack, 21, 0, -3.25);
  plateB.rotation.z = 0;
  const decalB = new THREE.Mesh(new THREE.PlaneGeometry(17, 4.25), decalMat);
  decalB.position.set(21, 0, -3.38);
  decalB.rotation.y = Math.PI;
  group.add(decalB);

  const hazardMat = new THREE.MeshBasicMaterial({
    map: hazardTexture,
    transparent: true,
    opacity: 0.86,
    depthWrite: false,
    toneMapped: false,
  });
  [
    [-29, 0.6, 3.36, 0],
    [-29, -0.6, -3.36, Math.PI],
    [1.5, 1.1, 3.36, 0],
  ].forEach(([x, y, z, ry]) => {
    const strip = new THREE.Mesh(new THREE.PlaneGeometry(7.5, 1.1), hazardMat);
    strip.position.set(x, y, z);
    strip.rotation.y = ry;
    group.add(strip);
  });

  /* ── rotating habitat ring ─────────────────────────────── */

  const habitat = new THREE.Group();
  habitat.position.x = 3;
  group.add(habitat);
  registerExplosionModule(habitat, 'habitat', '重力居住环', [0, 66, 0], 0.34);

  const ringMain = torus(habitat, 20.5, 1.85, hull, 128, 16);
  ringMain.rotation.y = Math.PI / 2;

  const ringInner = torus(habitat, 18.3, 0.22, glowCyan, 128, 8);
  ringInner.rotation.y = Math.PI / 2;

  const ringOuter = torus(habitat, 22.6, 0.42, hullDark, 128, 8);
  ringOuter.rotation.y = Math.PI / 2;

  // hub
  const hub = cylinder(habitat, 4.3, 4.3, 9.5, hullDark, 0, 0, 0, 32);
  hub.rotation.z = Math.PI / 2;
  const hubRingA = torus(habitat, 4.8, 0.3, gold, 40, 8);
  hubRingA.rotation.y = Math.PI / 2;
  hubRingA.position.x = 4.7;
  const hubRingB = hubRingA.clone();
  hubRingB.position.x = -4.7;
  habitat.add(hubRingB);

  for (let i = 0; i < 8; i += 1) {
    const a = (i / 8) * Math.PI * 2;
    const end = new THREE.Vector3(0, Math.cos(a) * 20.4, Math.sin(a) * 20.4);
    beam(habitat, new THREE.Vector3(0, 0, 0), end, 0.46, hullDark, 8);
    const collar = torus(habitat, 1.05, 0.18, gold, 20, 6);
    collar.position.copy(end).multiplyScalar(0.55);
    collar.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), new THREE.Vector3(0, -Math.sin(a), Math.cos(a)));
  }

  const podMaterial = random() > 0.5 ? hull : hullLight;
  for (let i = 0; i < 12; i += 1) {
    const a = (i / 12) * Math.PI * 2;
    const pod = new THREE.Group();
    pod.position.set(0, Math.cos(a) * 20.5, Math.sin(a) * 20.5);
    pod.rotation.x = a;
    habitat.add(pod);

    box(pod, 4.6, 3.1, 2.7, i % 5 === 0 ? gold : podMaterial);
    const window = box(pod, 2.7, 0.16, 0.72, i % 3 === 0 ? glowWarm : glowCyan, 0, 1.58, 0);
    window.rotation.z = 0;
    const window2 = box(pod, 0.18, 0.72, 1.35, glowCyan, 2.32, 0, 0);
    box(pod, 0.85, 0.5, 0.9, hullDark, -1.9, 1.3, 0);
    box(pod, 0.4, 0.4, 0.4, hullDark, 1.2, 1.6, 0.9);
  }

  // inner ring windows
  for (let i = 0; i < 48; i += 1) {
    const a = (i / 48) * Math.PI * 2;
    const w = box(habitat, 0.62, 0.16, 0.42, i % 4 === 0 ? glowWarm : glowCyan,
      -1.2, Math.cos(a) * 18.1, Math.sin(a) * 18.1);
    w.rotation.x = a;
  }

  // warm habitation lights along the outer rim
  for (let i = 0; i < 28; i += 1) {
    const a = (i / 28) * Math.PI * 2;
    const w = box(habitat, 0.7, 0.18, 0.52, i % 5 === 0 ? glowCyan : glowWarm,
      0.6, Math.cos(a) * 22.85, Math.sin(a) * 22.85);
    w.rotation.x = a;
  }

  /* ── outer service ring ────────────────────────────────── */

  const outerRing = new THREE.Group();
  outerRing.position.x = -10;
  group.add(outerRing);
  registerExplosionModule(outerRing, 'service', '服务环', [0, -50, 0], 0.2);

  const outerTorus = torus(outerRing, 29.5, 0.32, hullDark, 128, 8);
  outerTorus.rotation.y = Math.PI / 2;

  for (let i = 0; i < 4; i += 1) {
    const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
    const end = new THREE.Vector3(0, Math.cos(a) * 29.3, Math.sin(a) * 29.3);
    beam(outerRing, new THREE.Vector3(0, 0, 0), end, 0.24, hullDark, 6);

    const module = box(outerRing, 3.4, 1.8, 1.7, hullLight, 0, Math.cos(a) * 29.5, Math.sin(a) * 29.5);
    module.rotation.x = a;
    const light = box(outerRing, 0.2, 0.4, 0.4, glowWarm, 0, Math.cos(a) * 30.5, Math.sin(a) * 30.5);
    light.rotation.x = a;

    const antenna = cylinder(outerRing, 0.08, 0.08, 3.4, hullDark,
      0, Math.cos(a) * 31.4, Math.sin(a) * 31.4, 5);
    antenna.rotation.x = a;
  }

  /* ── solar wings ───────────────────────────────────────── */

  function buildWing(rootX, dir, span, width, height, scale = 1) {
    const wing = new THREE.Group();
    wing.position.x = rootX;
    wing.position.z = dir * 4.5;
    group.add(wing);

    const boomStart = new THREE.Vector3(0, 0, 0);
    const boomEnd = new THREE.Vector3(0, 0, dir * (span + 2));
    beam(wing, boomStart, boomEnd, 0.36 * scale, hullDark, 8);
    beam(wing, new THREE.Vector3(0, 0.9, 0), new THREE.Vector3(0, 0.9, dir * (span + 2)), 0.16, gold, 6);
    beam(wing, new THREE.Vector3(0, -0.9, 0), new THREE.Vector3(0, -0.9, dir * (span + 2)), 0.16, gold, 6);

    // ladder truss on boom
    for (let z = 2; z < span; z += 2.2) {
      beam(wing,
        new THREE.Vector3(0, 0.9, z),
        new THREE.Vector3(0, -0.9, z),
        0.07, hull, 4);
    }

    const panel = new THREE.Mesh(
      new THREE.BoxGeometry(0.28 * scale, height, width),
      solarMaterial
    );
    panel.position.set(0, 0, dir * (span + width / 2));
    wing.add(panel);

    // frame
    const zCenter = dir * (span + width / 2);
    const z0 = dir * span;
    const z1 = dir * (span + width);
    const framePoints = [
      [new THREE.Vector3(-0.3, height / 2, z0), new THREE.Vector3(-0.3, height / 2, z1)],
      [new THREE.Vector3(-0.3, -height / 2, z0), new THREE.Vector3(-0.3, -height / 2, z1)],
      [new THREE.Vector3(0.3, height / 2, z0), new THREE.Vector3(0.3, height / 2, z1)],
      [new THREE.Vector3(0.3, -height / 2, z0), new THREE.Vector3(0.3, -height / 2, z1)],
    ];
    framePoints.forEach(([a, b]) => beam(wing, a, b, 0.16, hullDark, 4));

    for (let y = -height / 2; y <= height / 2; y += height / 4) {
      beam(wing, new THREE.Vector3(0, y, z0), new THREE.Vector3(0, y, z1), 0.07, hullDark, 4);
    }

    // wing tip beacon
    const tip = glowSprite(glowTexture, dir > 0 ? 0xff6a6a : 0x7fffa8, 5.2);
    tip.position.set(0, 0, z1 * 1.02);
    wing.add(tip);
    beacons.push({ sprite: tip, speed: 2.1, phase: dir > 0 ? 0 : 1.4, base: 3.6 });

    registerExplosionModule(wing, 'solar', '聚变供能翼', [-16, 18, dir * 72], 0.12);

    return wing;
  }

  buildWing(-21, 1, 19, 30, 15, 1.05);
  buildWing(-21, -1, 19, 30, 15, 1.05);
  buildWing(17, 1, 10, 18, 10.5, 0.72);
  buildWing(17, -1, 10, 18, 10.5, 0.72);

  // gold joint fairings
  [-21, 17].forEach((x) => {
    box(group, 5.2, 3.2, 2.4, gold, x, 0, 0);
    box(group, 4.4, 2.2, 2.0, hullDark, x, 0, 0);
  });

  /* ── radiators ─────────────────────────────────────────── */

  function buildRadiator(x, y, z, flip = 1) {
    const rad = new THREE.Group();
    rad.position.set(x, y, z);
    rad.rotation.z = flip * 0.08;
    group.add(rad);

    box(rad, 15.5, 8.5, 0.18, white);
    for (let i = -7; i <= 7; i += 2.2) {
      box(rad, 0.08, 8.2, 0.2, hullDark, i, 0, 0.12);
    }
    for (let i = -4; i <= 4; i += 2) {
      box(rad, 15.2, 0.06, 0.2, hullDark, 0, i, 0.12);
    }
    beam(group, new THREE.Vector3(x - 7, y, z), new THREE.Vector3(x, y, 0), 0.24, hullDark, 6);
    registerExplosionModule(rad, 'radiator', '散热阵列', [-24, y > 0 ? 54 : -54, z > 0 ? 34 : -34], 0.24);
    return rad;
  }

  buildRadiator(-31, 9.5, 5.6, 1);
  buildRadiator(-31, 9.5, -5.6, -1);
  buildRadiator(-31, -9.5, 5.6, -1);
  buildRadiator(-31, -9.5, -5.6, 1);

  /* ── antenna dish ──────────────────────────────────────── */

  const dishGroup = new THREE.Group();
  dishGroup.position.set(26, 8.5, 1.5);
  group.add(dishGroup);
  registerExplosionModule(dishGroup, 'dish', '深空天线', [30, 62, 24], 0.3);

  const dishPoints = [];
  for (let i = 0; i <= 14; i += 1) {
    const t = i / 14;
    const r = t * 4.2;
    dishPoints.push(new THREE.Vector2(r, (r * r) / 6.2));
  }
  const dish = new THREE.Mesh(
    new THREE.LatheGeometry(dishPoints, 48),
    new THREE.MeshStandardMaterial({
      color: 0xd9dee5, metalness: 0.7, roughness: 0.38, side: THREE.DoubleSide,
    })
  );
  dishGroup.add(dish);

  const feed = cylinder(dishGroup, 0.13, 0.13, 3.0, gold, 0, 2.4, 0, 8);
  feed.position.y = 1.7;
  const feedTip = box(dishGroup, 0.75, 0.5, 0.75, hullDark, 0, 3.2, 0);
  feedTip.rotation.y = 0.4;

  // point the dish toward Earth
  const dishDir = new THREE.Vector3(-0.35, -0.82, -0.45).normalize();
  dishGroup.quaternion.setFromUnitVectors(Y_AXIS, dishDir);
  dishGroup.rotateY(0.2);

  beam(group, new THREE.Vector3(26, 2.2, 0), new THREE.Vector3(26, 8.5, 1.5), 0.7, hullDark, 8);
  const dishLight = glowSprite(glowTexture, 0x8fe9ff, 3.2);
  dishLight.position.set(26, 12.5, 1.5);
  group.add(dishLight);
  beacons.push({ sprite: dishLight, speed: 0.8, phase: 2.1, base: 2.2 });

  /* ── docking hub & tenders ─────────────────────────────── */

  const dock = new THREE.Group();
  dock.position.x = -34;
  group.add(dock);
  registerExplosionModule(dock, 'dock', '轨道对接港', [-52, -44, 0], 0.28);
  const dockHub = cylinder(dock, 5.1, 5.1, 8.0, hullDark, 0, 0, 0, 32);
  dockHub.rotation.z = Math.PI / 2;
  const dockRing = torus(dock, 5.3, 0.35, gold, 48, 8);
  dockRing.rotation.y = Math.PI / 2;

  for (let i = 0; i < 4; i += 1) {
    const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
    const dir = new THREE.Vector3(0, Math.cos(a), Math.sin(a));
    const end = dir.clone().multiplyScalar(9.5);
    beam(dock, new THREE.Vector3(0, 0, 0), end, 1.6, hull, 12);
    const portRing = torus(dock, 2.35, 0.4, hullDark, 32, 8);
    portRing.position.copy(end);
    portRing.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), dir);
    const portGlow = torus(dock, 1.7, 0.14, i === 0 ? glowWarm : glowCyan, 32, 6);
    portGlow.position.copy(end).addScaledVector(dir, 0.05);
    portGlow.quaternion.copy(portRing.quaternion);
    const clampA = box(dock, 1.1, 0.5, 0.55, hullDark, end.x, end.y + dir.y * 2.6, end.z + dir.z * 2.6);
    clampA.rotation.x = a;
  }

  // a small orbital tender docked below
  const tender = new THREE.Group();
  tender.position.set(-34, -19.5, 0);
  tender.rotation.z = -0.06;
  group.add(tender);
  registerExplosionModule(tender, 'tender', '轨道交通艇', [0, -64, 8], 0.32);
  const tenderBody = cylinder(tender, 1.7, 2.0, 7.5, hullLight, 0, 0, 0, 20);
  tenderBody.rotation.z = Math.PI / 2;
  box(tender, 1.4, 0.5, 5.0, hullDark, 0, 0.8, 0);
  box(tender, 1.0, 0.35, 4.0, hullDark, 0, -0.8, 0);
  const cockpit = box(tender, 0.4, 0.8, 1.4, glowCyan, 3.0, 0.2, 0);
  const engine = cylinder(tender, 1.05, 0.7, 1.4, hullDark, -4.1, 0, 0, 16);
  engine.rotation.z = Math.PI / 2;
  const engineGlow = glowSprite(glowTexture, 0x5fc8ff, 4.5);
  engineGlow.position.set(-5.0, 0, 0);
  tender.add(engineGlow);

  /* ── jump gate ─────────────────────────────────────────── */

  const gate = new THREE.Group();
  gate.position.x = -49;
  group.add(gate);
  registerExplosionModule(gate, 'gate', '天穹跃迁门', [-92, 0, 0], 0.06);

  const gateRotor = new THREE.Group();
  gate.add(gateRotor);

  const gateRing = torus(gateRotor, 42, 1.25, hullDark, 192, 12);
  gateRing.rotation.y = Math.PI / 2;
  const gateFacet = torus(gateRotor, 42, 2.15, hull, 192, 4);
  gateFacet.rotation.y = Math.PI / 2;
  const gateOuter = torus(gateRotor, 44.1, 0.32, gold, 192, 8);
  gateOuter.rotation.y = Math.PI / 2;
  const gateInnerGlow = torus(gateRotor, 40.3, 0.3, glowCyan, 192, 8);
  gateInnerGlow.rotation.y = Math.PI / 2;

  for (let i = 0; i < 18; i += 1) {
    const a = (i / 18) * Math.PI * 2;
    const seg = box(gateRotor, 3.6, 2.0, 7.2, i % 3 === 0 ? hullLight : hull,
      0, Math.cos(a) * 42, Math.sin(a) * 42);
    seg.rotation.x = a;
    const segGlow = box(gateRotor, 0.18, 0.4, 1.6, i % 4 === 0 ? glowWarm : glowCyan,
      0, Math.cos(a) * 39.9, Math.sin(a) * 39.9);
    segGlow.rotation.x = a;
  }

  const portalMaterial = new THREE.ShaderMaterial({
    uniforms: { time: { value: 0 } },
    vertexShader: /* glsl */`
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: /* glsl */`
      precision highp float;
      uniform float time;
      varying vec2 vUv;
      void main() {
        vec2 p = vUv - 0.5;
        float r = length(p) * 2.0;
        float a = atan(p.y, p.x);
        float swirl = sin(a * 7.0 + r * 22.0 - time * 0.55) * 0.5 + 0.5;
        float swirl2 = sin(a * -11.0 + r * 46.0 + time * 0.3) * 0.5 + 0.5;
        float edge = smoothstep(1.0, 0.25, r) * smoothstep(0.0, 0.1, r);
        float alpha = edge * (0.018 + swirl * 0.028 + swirl2 * 0.014);
        vec3 col = mix(vec3(0.12, 0.5, 1.0), vec3(0.65, 0.95, 1.0), swirl2);
        gl_FragColor = vec4(col * alpha * 4.0, alpha);
      }
    `,
    transparent: true,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const portal = new THREE.Mesh(new THREE.CircleGeometry(39.5, 128), portalMaterial);
  portal.rotation.y = Math.PI / 2;
  gateRotor.add(portal);

  // charged particles trapped in the jump gate's magnetic ring
  const gateParticleCount = 900;
  const gatePositions = new Float32Array(gateParticleCount * 3);
  for (let i = 0; i < gateParticleCount; i += 1) {
    const a = random() * Math.PI * 2;
    const r = 39.8 + (random() - 0.5) * 2.6;
    gatePositions[i * 3] = (random() - 0.5) * 3.2;
    gatePositions[i * 3 + 1] = Math.cos(a) * r;
    gatePositions[i * 3 + 2] = Math.sin(a) * r;
  }
  const gateParticleGeometry = new THREE.BufferGeometry();
  gateParticleGeometry.setAttribute('position', new THREE.BufferAttribute(gatePositions, 3));
  const gateParticles = new THREE.Points(
    gateParticleGeometry,
    new THREE.PointsMaterial({
      color: 0x9feeff,
      size: 1.25,
      transparent: true,
      opacity: 0.8,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
  gateRotor.add(gateParticles);

  // gate anchor struts (static, not in rotor)
  for (let i = 0; i < 4; i += 1) {
    const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
    const outer = new THREE.Vector3(0, Math.cos(a) * 42, Math.sin(a) * 42);
    const inner = new THREE.Vector3(14, Math.cos(a) * 6.8, Math.sin(a) * 6.8);
    beam(gate, outer, inner, 0.34, hullDark, 8);
    const joint = box(gate, 1.3, 1.3, 1.3, gold, inner.x, inner.y, inner.z);
    joint.rotation.set(a, a * 0.5, 0);
  }

  // gate light emitters
  for (let i = 0; i < 12; i += 1) {
    const a = (i / 12) * Math.PI * 2;
    const s = glowSprite(glowTexture, i % 3 === 0 ? 0xffb066 : 0x7fe7ff, 3.0);
    s.position.set(0, Math.cos(a) * 39.8, Math.sin(a) * 39.8);
    gate.add(s);
    beacons.push({ sprite: s, speed: 1.4, phase: i * 0.3, base: 2.3 });
  }
  const gateCoreLight = new THREE.PointLight(0x63d8ff, 420, 150, 2);
  gateCoreLight.position.set(-4, 0, 0);
  gate.add(gateCoreLight);

  /* ── engine nozzles / RCS ──────────────────────────────── */

  for (let i = 0; i < 4; i += 1) {
    const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
    const y = Math.cos(a) * 5.8;
    const z = Math.sin(a) * 5.8;
    const nozzle = cylinder(group, 1.4, 2.1, 4.0, hullDark, -37, y, z, 20);
    nozzle.rotation.z = Math.PI / 2;
    const ring = torus(group, 1.75, 0.2, copper, 24, 6);
    ring.rotation.y = Math.PI / 2;
    ring.position.set(-39, y, z);
    const exhaust = glowSprite(glowTexture, 0x5fb8ff, 5.0);
    exhaust.position.set(-40.8, y, z);
    group.add(exhaust);
    beacons.push({ sprite: exhaust, speed: 0.7, phase: i * 0.8, base: 2.8 });
  }

  /* ── running lights ────────────────────────────────────── */

  const navColors = [0xff5c5c, 0x7fffa0, 0xdff6ff, 0xffc078];
  for (let i = 0; i < 16; i += 1) {
    const x = -36 + random() * 74;
    const a = random() * Math.PI * 2;
    const s = glowSprite(glowTexture, navColors[i % navColors.length], 1.7 + random() * 1.2);
    s.position.set(x, Math.cos(a) * (3.1 + random() * 2), Math.sin(a) * (3.1 + random() * 2));
    group.add(s);
    beacons.push({ sprite: s, speed: 0.6 + random() * 1.8, phase: random() * 6.28, base: 1.4 });
  }

  /* ── service drones / floating traffic ────────────────── */

  const drones = [];
  for (let i = 0; i < 18; i += 1) {
    const s = glowSprite(glowTexture, i % 4 === 0 ? 0xffc078 : 0x9feeff, 1.0 + random() * 1.3);
    group.add(s);
    drones.push({
      sprite: s,
      radius: 48 + random() * 42,
      speed: 0.12 + random() * 0.34,
      phase: random() * Math.PI * 2,
      y: (random() - 0.5) * 28,
      incline: 0.65 + random() * 0.6,
    });
  }

  /* ── point lights for close-up warmth ─────────────────── */

  const ringLight = new THREE.PointLight(0x72dfff, 190, 70, 2);
  ringLight.position.set(3, 18, 0);
  group.add(ringLight);

  /* ── exploded assembly data ────────────────────────────── */

  const explosionParts = [];
  const moduleRoots = new Set(explosionModules.map((module) => module.object));
  const keepCore = new Set([spine, spineCore]);
  const tmpWorld = new THREE.Vector3();
  const tmpLocal = new THREE.Vector3();

  group.updateMatrixWorld(true);

  group.traverse((object) => {
    if (!object.isMesh || keepCore.has(object)) return;
    if (object.userData.noExplode) return;

    object.getWorldPosition(tmpWorld);
    tmpLocal.copy(tmpWorld);
    group.worldToLocal(tmpLocal);

    let direction = tmpLocal.clone();
    if (direction.lengthSq() < 9) {
      const a = random() * Math.PI * 2;
      direction.set(
        Math.cos(a),
        (random() - 0.5) * 1.6,
        Math.sin(a)
      );
    }
    direction.normalize();

    let underModule = false;
    let parent = object.parent;
    while (parent && parent !== group) {
      if (moduleRoots.has(parent)) {
        underModule = true;
        break;
      }
      parent = parent.parent;
    }

    object.geometry.computeBoundingSphere?.();
    const radius = object.geometry.boundingSphere?.radius ?? 2;
    const magnitude = underModule
      ? 3.4 + Math.min(8, radius * 0.35) + random() * 4.5
      : 5 + Math.min(15, radius * 0.3) + random() * 7.5;

    explosionParts.push({
      object,
      basePosition: object.position.clone(),
      offset: direction.multiplyScalar(magnitude),
      delay: underModule ? 0.24 + random() * 0.34 : 0.07 + random() * 0.34,
    });
  });

  const explosionLines = [];
  explosionModules.forEach((module) => {
    const start = module.basePosition.clone();
    const end = start.clone().add(module.offset);
    const geometry = new THREE.BufferGeometry().setFromPoints([start, end]);
    const material = new THREE.LineDashedMaterial({
      color: 0x8fe9ff,
      transparent: true,
      opacity: 0,
      dashSize: 3.2,
      gapSize: 2.2,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const line = new THREE.Line(geometry, material);
    line.computeLineDistances();
    group.add(line);
    explosionLines.push({ line, module });
  });

  let explodeValue = 0;
  let explodeTarget = 0;

  const smoothstep = (x) => {
    const t = THREE.MathUtils.clamp(x, 0, 1);
    return t * t * (3 - 2 * t);
  };

  function applyExplosion(value) {
    explosionModules.forEach((module) => {
      const k = smoothstep((value - module.delay) / Math.max(0.001, 1 - module.delay));
      module.object.position.copy(module.basePosition).addScaledVector(module.offset, k);
    });

    explosionParts.forEach((part) => {
      const k = smoothstep((value - part.delay) / Math.max(0.001, 1 - part.delay));
      part.object.position.copy(part.basePosition).addScaledVector(part.offset, k);
    });

    explosionLines.forEach(({ line, module }) => {
      const k = smoothstep((value - module.delay) / Math.max(0.001, 1 - module.delay));
      line.material.opacity = k * 0.34;
    });
  }

  function setExplode(value) {
    explodeTarget = THREE.MathUtils.clamp(value, 0, 1);
  }

  function getExplode() {
    return explodeValue;
  }

  const moduleSummary = [];
  const seenKeys = new Set();
  explosionModules.forEach((module) => {
    if (seenKeys.has(module.key)) return;
    seenKeys.add(module.key);
    moduleSummary.push({
      key: module.key,
      label: module.label,
      delay: module.delay,
    });
  });

  /* ── anchors for HUD markers ───────────────────────────── */

  function addAnchor(key, label, en, position, focusOffset, stats, description) {
    const obj = new THREE.Object3D();
    obj.position.copy(position);
    group.add(obj);
    anchors.push({ key, label, en, object: obj, focusOffset, stats, description });
    return obj;
  }

  addAnchor('command', '指挥核心', 'COMMAND CORE', new THREE.Vector3(49, 4, 0),
    new THREE.Vector3(150, 68, 168),
    [['功能', '航行指挥 / 跃迁控制'], ['乘员', '86 人'], ['状态', '在线']],
    '天穹站的神经中枢。环形全息指挥台围绕中央 AI 核心展开，负责轨道姿态、聚变供能与跃迁窗口计算。');

  addAnchor('habitat', '重力居住环', 'HABITAT RING', new THREE.Vector3(3, 21.5, 3),
    new THREE.Vector3(132, 82, 152),
    [['直径', '410 米'], ['重力', '0.92 G'], ['居住舱', '96 单元']],
    '十二组居住舱沿环体分布，以每分钟 1.8 转产生接近地球的重力。晨昏时分，整条环带会被地球的反照光染成蓝色。');

  addAnchor('solar', '聚变供能翼', 'SOLAR / FUSION WING', new THREE.Vector3(-21, 3, 36),
    new THREE.Vector3(132, 58, 166),
    [['翼展', '1.2 公里'], ['输出', '4.2 TW'], ['阵列', '18,400 单元']],
    '四组自适应太阳能翼在阴影期切换至聚变电池供能。翼面镀膜会随太阳风角度改变折射色，是轨道上最醒目的航标。');

  addAnchor('gate', '天穹跃迁门', 'HELIOS JUMP GATE', new THREE.Vector3(-49, 43, 0),
    new THREE.Vector3(122, 52, 202),
    [['直径', '2.4 公里'], ['曲率', '稳定'], ['下一次窗口', 'T- 04:12:36']],
    '站体最庞大的结构。四层超导环在真空中制造出一枚可穿越的曲率泡，将恒星际航程从数月压缩至数小时。');

  addAnchor('dock', '轨道对接港', 'ORBITAL DOCK', new THREE.Vector3(-34, -12, 0),
    new THREE.Vector3(132, 28, 146),
    [['泊位', '8 个'], ['在泊', '03'], ['补给', '已对接']],
    '八个重型泊位同时容纳深空拖船、跃迁护航舰与地表补给飞船。对接环会在接触前 30 秒自动充能。');

  /* ── update ────────────────────────────────────────────── */

  let elapsed = 0;

  function update(delta, timeScale = 1) {
    const d = delta * timeScale * 0.8;
    const motion = 1 - explodeValue * 0.84;
    elapsed += d;

    habitat.rotation.x += d * 0.085 * motion;
    outerRing.rotation.x -= d * 0.04 * motion;
    gateRotor.rotation.x += d * 0.022 * motion;
    portalMaterial.uniforms.time.value = elapsed;
    gateParticles.material.opacity = 0.55 + Math.sin(elapsed * 1.1) * 0.18;

    dishGroup.rotateY(d * 0.008 * motion);

    group.rotation.y = Math.sin(elapsed * 0.045) * 0.008 * motion;
    group.rotation.z = Math.sin(elapsed * 0.031) * 0.005 * motion;

    if (Math.abs(explodeValue - explodeTarget) > 0.0008) {
      const rate = explodeTarget > explodeValue ? 1.55 : 2.4;
      explodeValue += (explodeTarget - explodeValue) * (1 - Math.exp(-rate * delta));
      if (Math.abs(explodeTarget - explodeValue) < 0.01) explodeValue = explodeTarget;
      applyExplosion(explodeValue);
    }

    beacons.forEach((b) => {
      const pulse = 0.32 + Math.pow(Math.abs(Math.sin(elapsed * b.speed + b.phase)), 6) * 0.95;
      b.sprite.material.opacity = pulse;
      b.sprite.scale.setScalar(b.base * (0.72 + pulse * 0.45));
    });

    drones.forEach((drone) => {
      const a = elapsed * drone.speed + drone.phase;
      drone.sprite.position.set(
        Math.cos(a) * drone.radius,
        drone.y + Math.sin(a * 1.4 + drone.phase) * 9,
        Math.sin(a) * drone.radius * drone.incline
      );
      drone.sprite.material.opacity = 0.35 + Math.abs(Math.sin(elapsed * 1.7 + drone.phase)) * 0.55;
    });

    ringLight.intensity = 175 + Math.sin(elapsed * 0.8) * 35;
  }

  return {
    group,
    update,
    anchors,
    beacons,
    setExplode,
    getExplode,
    explosionModules: moduleSummary,
    partCount: explosionParts.length,
  };
}
